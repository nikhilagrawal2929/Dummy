package com.company.automation.testautomation.pages.umh;

import com.company.automation.automationframework.pageengine.Page;
import com.company.automation.testautomation.helpers.general.selenium.WebElementHelper;
import org.openqa.selenium.WebDriver;

public class LogoutPage extends Page
{

  public LogoutPage(WebDriver driver)
  {
    super(driver);
  }

  public static final String LOGIN_AGAIN_BTN_XPATH = "//button[@class='btn btn-lg btn-primary btn-block mb-2']";

  public void clickLoginAgainBtn(WebDriver driver)
  {
    WebElementHelper.clickButton(driver, "user info tab", LOGIN_AGAIN_BTN_XPATH);
  }
}
