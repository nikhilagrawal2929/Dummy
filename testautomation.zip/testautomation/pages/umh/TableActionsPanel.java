package com.company.automation.testautomation.pages.umh;

import com.company.automation.automationframework.pageengine.Page;
import com.company.automation.automationframework.testlog.TestLog;
import com.company.automation.testautomation.enums.umh.PagesEnum;
import com.company.automation.testautomation.enums.umh.TouchpointContentViewPanelValueEnum;
import com.company.automation.testautomation.helpers.general.selenium.ActionsHelper;
import com.company.automation.testautomation.helpers.general.selenium.WebElementHelper;
import com.company.automation.testautomation.helpers.general.selenium.WindowsActionsHelper;
import com.company.automation.testautomation.pages.umh.data.resources.AddAndEditDataFilePanel;
import com.company.automation.testautomation.pages.umh.data.resources.AddAndEditDataResourcePanel;
import com.company.automation.testautomation.pages.umh.data.variables.AddAndEditViewVariablePanel;
import com.company.automation.testautomation.pages.umh.target.AddTargetGroupPage;
import com.company.automation.testautomation.pages.umh.target.AddTargetingRulePage;
import com.company.automation.testautomation.pages.umh.touchpoints.MessagesPage;
import com.company.automation.testautomation.pages.umh.touchpoints.VariantsPanel;
import com.company.automation.testautomation.pages.umh.touchpoints.ViewContentPage;
import com.company.automation.testautomation.pages.umh.touchpoints.ViewDetailsPage;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TableActionsPanel extends NavigationBarAndFooterTemplatePage
{
  protected static final String ADD_BUTTON_XPATH                                = "//*[@class='far fa-plus-circle mr-2']";
  protected static final String EDIT_BUTTON_XPATH                               = "//button[@id='updateBtn']"; //"//*[@class='far fa-edit mr-2']";
  protected static final String DELETE_BUTTON_XPATH                             = "//button[@id='deleteBtn']"; //"//*[@class='far fa-trash-alt mr-2']";
  protected static final String MORE_BUTTON_XPATH                               = "//span[text() = 'More']";
  protected static final String TOGGLE_COLUMNS_BUTTON_XPATH                     = "//*[@class='btn dropdown-toggle btn-link btn-link-inline fs-md text-dark']";
  protected static final String SEARCH_XPATH                                    = "//*[@id='listSearchInput']";
  protected static final String TABLE_IS_EMPTY_MARKER                           = "//*[@class='dataTables_empty']";
  protected static final String SEARCH_MATCH_ROWS                               = "//*[@class='dataTablesSearchMatch']";
  protected static final String LIST_OF_ROWS_IN_TABLE                           = "//*[@role='row']";
  protected static final String FRAME_DETAILS_PAGE_ID                           = "//*[@class='iFramePopupFrame']";
  protected static final String MORE_VALUES_PATTERN                             = "//button[text()='%s']";
  public static final    String CONFIRM_BTN                                     = "//*[@id='actionPopupStandardButtons']//*[@id='link_Continue']";
  private static final   String MESSAGES_SHOW_ALL_PAGES_XPATH                   = "//*[@id='messageList_entry-select']";
  private static final   String LOCAL_SMART_TEXT_AND_IMAGE_SHOW_ALL_PAGES_XPATH = "//*[@id='smartContentList_entry-select']";
  private static final   String VARIANTS_SHOW_ALL_PAGES_XPATH                   = "//*[@id='selectionList_entry-select']";
  private static final   String VARIANTS_SEARCH_FIELD_XPATH                     = "//*[@class='col']" + SEARCH_XPATH;
  private static final   String SEARCH_RESULT_PATTERN                           = "//*[contains(text(), '%s') or text()='No matching entries found']";
  private static final   String PROGRESS_LOADER_XPATH                           = "//*[contains(@class, 'progress-loader-container')]";

  public TableActionsPanel(WebDriver driver)
  {
    super(driver);
  }

  public Page clickAddBtn(PagesEnum page)
  {
    TestLog.step("Start to click add button");
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, ADD_BUTTON_XPATH, 0);
    WebElementHelper.clickButton(driver, "Add", ADD_BUTTON_XPATH);

    switch (page)
    {
    case VARIANTS_PAGE:
      return new VariantsPanel(driver);
    case MESSAGES_PAGE:
    case LOCAL_IMAGES_PAGE:
    case LOCAL_SMART_TEXT:
      return new ViewDetailsPage(driver);
    case ADD_TARGET_GROUP_PAGE:
      return new AddTargetGroupPage(driver);
    case ADD_TARGETING_RULE_PAGE:
      return new AddTargetingRulePage(driver);
    case ADD_VARIABLE_PAGE:
      return new AddAndEditViewVariablePanel(driver);
    case ADD_RESOURCE_PAGE:
      return new AddAndEditDataResourcePanel(driver);
    case ADD_DATA_FILES_PAGE:
      return new AddAndEditDataFilePanel(driver);
    default:
      return new MessagesPage(driver);
    }
  }

  public Page clickEditBtn(PagesEnum page)
  {
    TestLog.step("Start to click edit button");
    WebElementHelper.waitForElementToBeClickable(driver, By.xpath(EDIT_BUTTON_XPATH), 5);
    WebElementHelper.clickButton(driver, "Edit", EDIT_BUTTON_XPATH);

    switch (page)
    {
    case VARIANTS_PAGE:
      return new VariantsPanel(driver);
    case MESSAGES_PAGE:
      return new ViewDetailsPage(driver);
    case LOCAL_IMAGES_PAGE:
    case LOCAL_SMART_TEXT:
      return new ViewContentPage(driver);
    case ADD_TARGET_GROUP_PAGE:
      return new AddTargetGroupPage(driver);
    case ADD_TARGETING_RULE_PAGE:
      return new AddTargetingRulePage(driver);
    case ADD_VARIABLE_PAGE:
      return new AddAndEditViewVariablePanel(driver);
    default:
      return new MessagesPage(driver);
    }
  }

  public void clickDeleteBtn()
  {
    TestLog.step("Start to click delete button");
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver,DELETE_BUTTON_XPATH,0);
    WebElementHelper.clickButton(driver, "Delete", DELETE_BUTTON_XPATH);
  }

  public void clickMoreBtn()
  {
    TestLog.step("Start to click more button");
    WebElementHelper.waitUntilElementToBeClickable(driver, MORE_BUTTON_XPATH);
    WebElementHelper.clickButton(driver, "More", MORE_BUTTON_XPATH);
  }

  public void searchItemByName(String name)
  {
    WebElementHelper.waitUntilInvisibilityOfElementLocated(driver, PROGRESS_LOADER_XPATH);
    WebElementHelper.waitForTableToLoad(driver);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, SEARCH_XPATH, 0);

    String searchFieldXpath = WebElementHelper.getElements(driver, SEARCH_XPATH).size() > 1 ? VARIANTS_SEARCH_FIELD_XPATH : SEARCH_XPATH;
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, searchFieldXpath, 0);
    WebElementHelper.enterTextToTextField(driver, "Search", name, searchFieldXpath);

    String searchResultXpath = String.format(SEARCH_RESULT_PATTERN, name);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, searchResultXpath, 0);
    WebElementHelper.waitForTableToLoad(driver);
  }

  public boolean checkThatTableIsEmpty()
  {
    TestLog.step("Start to check that table is empty");
    boolean isTableEmpty = WebElementHelper.isElementDisplayed(driver, TABLE_IS_EMPTY_MARKER, 5);
    TestLog.step("Table is empty, result:[" + isTableEmpty + "]");

    return isTableEmpty;
  }

  public void switchToFrame()
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, FRAME_DETAILS_PAGE_ID, 0);
    WebElement frame = WebElementHelper.getElement(driver, FRAME_DETAILS_PAGE_ID);
    WindowsActionsHelper.waitUntilFrameLoadAndSwitch(driver, 15, frame);
    WebElementHelper.waitForJavascriptDone(driver);
  }

  public void selectValueFromMore(String value)
  {
    String xpath = String.format(MORE_VALUES_PATTERN, value);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, xpath, 0);
    WebElementHelper.clickElement(driver, "select [" + value + "] from more", xpath);
  }

  public void clickConfirmBtn()
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, CONFIRM_BTN, 0);
    WebElementHelper.clickButton(driver, "confirm", CONFIRM_BTN);
  }

  public void showAllPages(TouchpointContentViewPanelValueEnum content)
  {
    String showAllPagesXpath;
    switch (content)
    {
    case VARIANTS:
      showAllPagesXpath = VARIANTS_SHOW_ALL_PAGES_XPATH;
      break;
    case MESSAGES:
      showAllPagesXpath = MESSAGES_SHOW_ALL_PAGES_XPATH;
      break;
    default:
      showAllPagesXpath = LOCAL_SMART_TEXT_AND_IMAGE_SHOW_ALL_PAGES_XPATH;
    }

    WebElementHelper.selectOptionFromDropdownByText(driver, showAllPagesXpath, "All");
  }
}
