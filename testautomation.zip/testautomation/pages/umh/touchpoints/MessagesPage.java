package com.company.automation.testautomation.pages.umh.touchpoints;

import com.company.automation.automationframework.pageengine.Page;
import com.company.automation.automationframework.testlog.TestLog;
import com.company.automation.testautomation.enums.umh.MoreActionsListEnum;
import com.company.automation.testautomation.enums.umh.TableItemStatusEnum;
import com.company.automation.testautomation.enums.umh.TouchpointContentViewPanelValueEnum;
import com.company.automation.testautomation.helpers.general.selenium.ActionsHelper;
import com.company.automation.testautomation.helpers.general.selenium.WebElementHelper;
import com.company.automation.testautomation.helpers.general.selenium.WindowsActionsHelper;
import com.company.automation.testautomation.pages.umh.TableActionsPanel;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class MessagesPage extends TableActionsPanel
{
  private static final String FOUND_ITEM_BY_SEARCH_XPATH                   = "//*[@class='dataTableLink d-inline-block w-100 text-truncate dataTableItemName text-pre']";
  private static final String ZONES_LIST_BTN                               = "//*[@id='zoneSelect-toggle']";
  private static final String SECTIONS_AND_ZONES_AND_MESSAGESTATUS_PATTERN = "//button[contains(text(), '%s')]";
  private static final String MESSAGE_STATE_LIST_XPATH                     = "//*[@id='contentObjectListStatusFilter-toggle']/span";
  private static final String MORE_ACTION_LIST_PATTERN                     = "//*[@data-option-value='%s' or @data-option-value=' %s']";
  private static final String USER_NOTE_XPATH                              = "//*[@id='userNote']";
  private static final String SUBMIT_BTN_XPATH                             = "//*[@submit_id]";
  private static final String SELECTED_TOUCHPOINT_XPATH                    = "//*[@class='touchpointContextName mr-auto text-left w-100 text-nowrap text-truncate']";
  private static final String SEARCH_TOUCHPOINT_INPUT_XPATH                = "//input[@id='touchpointSearchInput']";
  private static final String SEARCH_TOUCHPOINT_IFRAME_XPATH               = "//div[@class='iFrameMenuFrameContainer']/iframe";
  private static final String SEARCH_TOUCHPOINT_RESULT_ITEM                = "//div[@class='touchpointListItemsContainer touchpointListItems backgroundTile_10p']/div[@searchname=\"%s\"]";
  private static final String POPUP_TITLE_XPATH                            = "//*[@id='actionPopupTitle']";
  private static final String SELECT_ITEM_BY_STATUS                        = "//*[@data-original-title='%s']/../..//*[@class='row-control custom-control custom-checkbox no-text']";
  private static final String TOUCHPOINT_CONTENT_VIEW_PANEL                = "//*[@id='touchpointContentViewToggle']";
  private static final String TOUCHPOINT_CONTENT_VALUE_PATTERN             = "//*[@class='dropdown-item' and contains(text(), '%s')]";
  private static final String ACTION_POPUP_XPATH                           = "//*[@id='actionPopup']";
  private static final String SECTION_XPATH                                = "//*[@data-dropdown-class='btn-lg btn-blank w-100 dropdown-flexblock' and @aria-label='Section']";
  private static final String MESSAGE_LIST_PROCESSING                      = "//*[@id='messageList_processing']";
  private static final String MESSAGE_OPENED_XPATH                         = "//*[@class='h4 d-flex align-items-baseline pb-3 mb-4 border-bottom border-thick font-weight-normal']";
  private static final String DROPDOWN_PATTERN                             = "//button[contains(text(), '%s')]";
  public MessagesPage(WebDriver driver)
  {
    super(driver);
  }

  public ViewContentPage clickToMessage()
  {
    TestLog.step("Try to click on message");
    WebElementHelper.waitUntilNumberOfElementsLessThanExpResultByXpath(driver, FOUND_ITEM_BY_SEARCH_XPATH, 2);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, FOUND_ITEM_BY_SEARCH_XPATH, 0);
    WebElementHelper.clickElement(driver, "Message", FOUND_ITEM_BY_SEARCH_XPATH);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, MESSAGE_OPENED_XPATH,1);
    return new ViewContentPage(driver);
  }

  public void selectSectionByName(String section)
  {
    TestLog.step("Start to select section");
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, SECTION_XPATH, 0);
    String selectedOption = WebElementHelper.getSelectedOptionFromDropdown(driver, SECTION_XPATH);
    if (selectedOption.compareTo(section) != 0)
    {
      ActionsHelper.moveToElementAndClick(driver,SECTION_XPATH);
      String valueXpath = String.format(DROPDOWN_PATTERN, section);
      WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver,valueXpath,0);
      ActionsHelper.moveToElementAndClick(driver,valueXpath);
    }
  }

  public void selectZoneByName(String zone)
  {
    TestLog.step("Start to select zone");
    WebElementHelper.waitForJavascriptDone(driver);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, ZONES_LIST_BTN, 0);
    WebElementHelper.waitUntilElementToBeClickable(driver, ZONES_LIST_BTN);
    WebElementHelper.clickElement(driver, "Zones", ZONES_LIST_BTN);

    String xpath = String.format(SECTIONS_AND_ZONES_AND_MESSAGESTATUS_PATTERN, zone);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, xpath, 0);
    WebElementHelper.clickElement(driver, "Select zone with name: [" + zone + "]", xpath);
  }

  private void openMessageStateFilterDropDown()
  {
    TestLog.step("Start to open message state dropdown");
    WebElementHelper.waitForTableToLoad(driver);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpathWithCustomWait(driver, 5, MESSAGE_STATE_LIST_XPATH, 0);
    WebElementHelper.openDropdown(driver, "message status", MESSAGE_STATE_LIST_XPATH);
  }

  public void filterMessagesByStatusInMessageTable(TableItemStatusEnum statusEnum)
  {
    String state = statusEnum.getStatus();
    TestLog.step("Start to filter message by status: [" + state + "]");
    String xpath = String.format(SECTIONS_AND_ZONES_AND_MESSAGESTATUS_PATTERN, state);
    openMessageStateFilterDropDown();
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpathWithCustomWait(driver, 5, xpath, 0);
    WebElement messageStatus = WebElementHelper.getElement(driver, xpath);
    WebElementHelper.waitUntilElementToBeClickable(driver, messageStatus);
    WebElementHelper.selectValueFromList(state, "message state filters", messageStatus);
  }

  public void clickContinueOnMessagePageDialogPopup()
  {
    TestLog.step("Try to click 'continue' button on message page dialog popup");
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, POPUP_TITLE_XPATH, 0);
    WebElement popupTitleElement = WebElementHelper.getElement(driver, POPUP_TITLE_XPATH);
    String popupTitle = WebElementHelper.getTextFromWebElement(driver, "message confirm popup", popupTitleElement);
    TestLog.step("Try to popup with title [" + popupTitle + "]");
    WebElementHelper.clickButton(driver, "Continue", SUBMIT_BTN_XPATH);
    WebElementHelper.waitForJavascriptDone(driver);
    WebElementHelper.waitUntilElemDisappear(driver, 60, ACTION_POPUP_XPATH);
  }

  private void clickMessageStateList()
  {
    TestLog.step("Try to click message state list");
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpathWithCustomWait(driver, 5, MESSAGE_STATE_LIST_XPATH, 0);
    WebElementHelper.clickElement(driver, "Message state list", MESSAGE_STATE_LIST_XPATH);
  }

  public void filterMessageByStatusAndDisplayInTable(TableItemStatusEnum tableItemStatusEnum)
  {
    String status = tableItemStatusEnum.getStatus();
    TestLog.step("Start to filter messages by status [" + status + "]");
    String xpath = String.format(SECTIONS_AND_ZONES_AND_MESSAGESTATUS_PATTERN, status);
    clickMessageStateList();
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpathWithCustomWait(driver, 5, xpath, 0);
    WebElementHelper.clickElement(driver, "Select message status", xpath);
    if (WebElementHelper.isElementDisplayed(driver, MESSAGE_LIST_PROCESSING, 5))
    {
      WebElementHelper.waitUntilElemDisappear(driver, 10, MESSAGE_LIST_PROCESSING);
    }
  }

  public String getSelectedTouchpoint()
  {
    TestLog.step("Try to get selected Touchpoint");
    WebElement el = WebElementHelper.getElement(driver, SELECTED_TOUCHPOINT_XPATH);
    String selectedTouchpoint = WebElementHelper.getTextFromWebElement(driver, "selected touchpoint", el);
    TestLog.step("Retrieved selected Touchpoint:[" + selectedTouchpoint + "]");

    return selectedTouchpoint;
  }

  public void selectActionFromMoreList(MoreActionsListEnum actionEnum)
  {
    String actionName = actionEnum.getAction();
    TestLog.step("Start to select [" + actionName + "] from more list");
    String xpath = String.format(MORE_ACTION_LIST_PATTERN, actionName, actionName);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, xpath, 0);
    WebElementHelper.clickButton(driver, "[" + actionName + "] from [More] list ", xpath);
  }

  public void enterUserNote(String note)
  {
    TestLog.step("Start to enter user note [" + note + "]");
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpathWithCustomWait(driver, 3, USER_NOTE_XPATH, 0);
    WebElementHelper.clickElement(driver, "user note", USER_NOTE_XPATH);
    WebElementHelper.enterTextToTextField(driver, "Note", "Automation", USER_NOTE_XPATH);
  }

  public boolean selectAllMessagesByStatus(TableItemStatusEnum statusEnum)
  {
    String status = statusEnum.getStatus();
    TestLog.step("Start to select all messages by status [" + status + "] from message table");
    ActionsHelper.sleep(3000);

    String xpath = String.format(SELECT_ITEM_BY_STATUS, status);
    if (WebElementHelper.isElementDisplayed(driver, xpath, 3))
    {
      List<WebElement> messagesList = WebElementHelper.getElements(driver, xpath);
      messagesList.forEach(WebElement::click);
      return !messagesList.isEmpty();
    }
    return false;
  }

  public Page switchToTouchpointContentByPageName(TouchpointContentViewPanelValueEnum valueEnum)
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, TOUCHPOINT_CONTENT_VIEW_PANEL, 0);
    WebElement tpContent = WebElementHelper.getElement(driver, TOUCHPOINT_CONTENT_VIEW_PANEL);
    String currentTpPage = WebElementHelper.getTextFromWebElement(driver, "Get touchpoint content", tpContent);
    String tpPageFromEnum = valueEnum.getValue();
    if (currentTpPage.trim().compareTo(tpPageFromEnum) == 0)
    {
      return defineTpPage(valueEnum);
    }

    WebElementHelper.clickButton(driver, "Touchpoint content", TOUCHPOINT_CONTENT_VIEW_PANEL);
    String xpath = String.format(TOUCHPOINT_CONTENT_VALUE_PATTERN, valueEnum.getValue());
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, xpath, 0);
    WebElementHelper.clickElement(driver, valueEnum.getValue(), xpath);

    return defineTpPage(valueEnum);
  }

  public Page defineTpPage(TouchpointContentViewPanelValueEnum valueEnum)
  {
    WebElementHelper.waitForTableToLoad(driver);
    switch (valueEnum)
    {
    case VARIANTS:
      return new VariantsPage(driver);
    case LOCAL_SMART_TEXT:
      return new LocalSmartTextPage(driver);
    case LOCAL_IMAGES:
      return new LocalImagePage(driver);
    case MESSAGES:
    default:
      return new MessagesPage(driver);
    }
  }

  public MessagesPage changeTouchPointByName(String touchPointName)
  {
    TestLog.step("Try to change selected Touchpoint to [" + touchPointName + "]");

    TestLog.subStep("Try to open Touchpoint selection dropdown list");
    WebElement el = WebElementHelper.getElement(driver, SELECTED_TOUCHPOINT_XPATH);
    ActionsHelper.moveToElementAndClick(driver, el);

    TestLog.subStep("Try to fill in the touchpoint's name into the search box: [" + touchPointName + "]");
    WebElement iframe = WebElementHelper.getElement(driver, SEARCH_TOUCHPOINT_IFRAME_XPATH);
    WebElement input = WebElementHelper.getElement(driver.switchTo().frame(iframe), SEARCH_TOUCHPOINT_INPUT_XPATH);
    WebElementHelper.enterTextToTextField("Touchpoint search box", touchPointName, input);

    TestLog.subStep("Try to click the touchpoint from the result list");
    String xpath = String.format(SEARCH_TOUCHPOINT_RESULT_ITEM, touchPointName);
    WebElement touchpointResult = WebElementHelper.getElement(driver, xpath);
    ActionsHelper.moveToElementAndClick(driver, touchpointResult);

    WindowsActionsHelper.switchToParentWindow(driver);

    TestLog.step("Changed selected Touchpoint to: [" + touchPointName + "]");
    return new MessagesPage(driver);
  }

  public void chooseInstanceAndTouchpoint(MessagesPage messagesPage, String instance, String user, String password, String tp)
  {
    messagesPage.chooseInstanceByName(instance, user, password);
    messagesPage.chooseTouchpointByName(tp);
  }
}
