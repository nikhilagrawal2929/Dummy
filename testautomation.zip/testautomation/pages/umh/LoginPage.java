package com.company.automation.testautomation.pages.umh;

import com.company.automation.automationframework.pageengine.Page;
import com.company.automation.automationframework.profile.LoginProfile;
import com.company.automation.automationframework.testlog.TestLog;
import com.company.automation.testautomation.helpers.general.selenium.WebElementHelper;
import com.company.automation.testautomation.pages.umh.touchpoints.MessagesPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage extends Page
{
  public static final String COMPANY_NAME_FIELD_XPATH  = "//input[@id='branchInput']";
  public static final String EMAIL_FIELD_XPATH         = "//input[@id='emailInput']";
  public static final String PASSWORD_FIELD_XPATH      = "//input[@id='passwordInput']";
  public static final String INSTANCE_FIELD_XPATH      = "//input[@id='nodeInput']";
  public static final String TOGGLE_INSTANCE_BTN_XPATH = "//button[@id='showInstaceInput']";
  public static final String LOGIN_BTN_XPATH           = "//span[contains ( text(), 'Log in')]";
  public static final String VERSION_FIELD_XPATH       = "//span[@class='ml-2'][2]";

  public LoginPage(WebDriver driver)
  {
    super(driver);
  }

  public void getToLoginPage(LoginProfile loginProfile, WebDriver driver)
  {
    driver.get(loginProfile.getBaseUrl());
  }

  public void clickToggleInstanceBtn(WebDriver driver)
  {
    WebElementHelper.clickButton(driver, "Toggle instance", TOGGLE_INSTANCE_BTN_XPATH);
  }

  public void enterCompanyName(WebDriver driver, String companyNameStr)
  {
    WebElementHelper.enterTextToTextField(driver, "company name", companyNameStr, COMPANY_NAME_FIELD_XPATH);
  }

  public void enterInstanceInfo(WebDriver driver, String instanceNameStr)
  {
    WebElementHelper.enterTextToTextField(driver, "instance", instanceNameStr, INSTANCE_FIELD_XPATH);
  }

  public void enterUsername(WebDriver driver, String usernameStr)
  {
    WebElementHelper.enterTextToTextField(driver, "email", usernameStr, EMAIL_FIELD_XPATH);
  }

  public void enterPassword(WebDriver driver, String passwordStr)
  {
    WebElementHelper.enterTextToTextField(driver, "password", passwordStr, PASSWORD_FIELD_XPATH);
  }

  public MessagesPage clickLoginBtn(WebDriver driver)
  {
    WebElementHelper.clickButton(driver, "login", LOGIN_BTN_XPATH);
    return new MessagesPage(driver);
  }

  public String getProductVersion(WebDriver driver, boolean showInSteps)
  {
    WebElement element = WebElementHelper.getElement(driver, VERSION_FIELD_XPATH);
    String productVersion = element.getText();

    if (showInSteps)
      TestLog.step("Product version:[" + productVersion + "]");
    return productVersion;
  }
}
