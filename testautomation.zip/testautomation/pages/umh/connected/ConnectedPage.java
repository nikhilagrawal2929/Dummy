package com.company.automation.testautomation.pages.umh.connected;

import com.company.automation.automationframework.testlog.TestLog;
import com.company.automation.testautomation.enums.connected.ConnectedTableEnum;
import com.company.automation.testautomation.helpers.connected.ConnectedTableHelper;
import com.company.automation.testautomation.helpers.general.TableHelper;
import com.company.automation.testautomation.helpers.general.selenium.ActionsHelper;
import com.company.automation.testautomation.helpers.general.selenium.WebElementHelper;
import com.company.automation.testautomation.pages.umh.NavigationBarAndFooterTemplatePage;
import com.company.automation.testautomation.templates.TableSegment;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ConnectedPage extends NavigationBarAndFooterTemplatePage
{

  public static final int          FIRST_ROW                                = 1;
  public static final String       CREATED                                  = "Created";
  public static final String       MORE_BTN_XPATH                           = "//span[contains(text(),'More')]";
  public static final String       CONTINUE_BTN_XPATH                       = "//*[@id='link_Continue']";
  public static final String       DELETE_BTN_XPATH                         = "//*[contains(@data-option-value, 'Delete')]";
  public static final String       DESCENDING_XPATH                         = "//*[@aria-sort='descending']";
  public final static String       INFO_MESSAGE_CONNECTED_NOT_ENABLED_XPATH = "//*[@id='infoMsg_connectedNotEnabled']";
  public static final String       ORDERS_LIST_TABLE_XPATH                  = "//table[@id='communicationsList']";
  public static final String       ADD_ORDER_BUTTON_XPATH                   = "//*[@id='addCommunicationBtn']";
  final static        String       LIST_SEARCH_TEXT_XPATH                   = "//*[@id='listSearchInput']";
  private             TableSegment table                                    = null;
  public static final String       LOAD_TABLE_MARKER                        = "//*[@id='communicationsList_processing']";
  public static final String       CONFIRM_DELETE_POPUP                     = "//*[@class='popupWindow_minimal popupContentWidth ui-draggable']";
  public static final int          EXP_ITEMS                                = 0;
  public static final String       IS_TABLE_EMPTY_INDICATOR                 = "//*[@class='dataTables_empty']";

  public ConnectedPage(WebDriver driver)
  {
    super(driver);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, LOAD_TABLE_MARKER, EXP_ITEMS);
    table = TableHelper.initOrUpdateTable(driver, table, ORDERS_LIST_TABLE_XPATH);
  }

  public String getTextFromCellByRow(WebDriver driver, ConnectedTableEnum columnEnum, int row)
  {
    int column = columnEnum.getColumnNumber();
    String text = ConnectedTableHelper.getTextFromCellByColumnAndRow(driver, column, row);
    TestLog.step("Try to get text [" + text + "] from:[" + columnEnum.name() + "] column, in row:[" + row + "]");

    return text;
  }

  public AddOrderPage clickAddOrderBtn()
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, ORDERS_LIST_TABLE_XPATH, EXP_ITEMS);
    WebElementHelper.clickButton(driver, "add order", ADD_ORDER_BUTTON_XPATH);
    return new AddOrderPage(driver);
  }

  public boolean isConnectedNotEnabled()
  {
    boolean messageExists = WebElementHelper.isElementExistsByXpath(driver, INFO_MESSAGE_CONNECTED_NOT_ENABLED_XPATH);
    return messageExists;
  }

  public void enterTextToSearchField(WebDriver driver, String strText)
  {
    WebElementHelper.enterTextToTextField(driver, "search field", strText, LIST_SEARCH_TEXT_XPATH);
  }

  public void clickMoreBtn(WebDriver driver)
  {
    WebElementHelper.clickButton(driver, "more", MORE_BTN_XPATH);
  }

  public void clickDeleteBtn()
  {
    WebElementHelper.clickButton(driver, "delete", DELETE_BTN_XPATH);
  }

  public void clickContinueBtn()
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, CONTINUE_BTN_XPATH, 0);
    WebElementHelper.clickButton(driver, "continue", CONTINUE_BTN_XPATH);
    ActionsHelper.sleep(3000);
  }

  public String getEmptyTableLabel()
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, IS_TABLE_EMPTY_INDICATOR, 0);
    WebElement label = WebElementHelper.getElement(driver, IS_TABLE_EMPTY_INDICATOR);
    String text = label.getText();
    return text;
  }
}
