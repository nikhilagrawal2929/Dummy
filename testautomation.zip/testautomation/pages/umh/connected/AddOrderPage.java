package com.company.automation.testautomation.pages.umh.connected;

import com.company.automation.automationframework.testlog.TestLog;
import com.company.automation.testautomation.helpers.general.selenium.ActionsHelper;
import com.company.automation.testautomation.helpers.general.selenium.DatePickerHelper;
import com.company.automation.testautomation.helpers.general.selenium.DropDownListHelper;
import com.company.automation.testautomation.helpers.general.selenium.WebElementHelper;
import com.company.automation.testautomation.pages.umh.NavigationBarAndFooterTemplatePage;
import com.company.automation.testautomation.templates.NoSuchTableRowException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

public class AddOrderPage extends NavigationBarAndFooterTemplatePage
{

  public static final String BUTTON_CONTINUE_XPATH          = "//*[@id='btnContinue']";
  public static final String BUTTON_CANCEL_XPATH            = "//*[@id='btnCancel']";
  public static final String BUTTON_DROPDOWN_XPATH          = "//*[@id='btnClearAndContinue']";
  public static final String RESET_CONTENT_AND_CONTINUE_BTN = "//*[text()='Reset content and continue']";
  public static final String LABEL_DROPDOWN_PATTERN         = "//div[@style='display: block;']/label[span=\"%s\"]";
  public static final String LABEL_PATTERN                  = "//label[span=\"%s\"]";
  public static final String CHOOSE_FROM_MENU_PATTERN       = "//ul/li[text()='%s']";

  public static final String LINK_ELEMENT_XPATH                  = "/../div";
  public static final String INPUT_ELEMENT_XPATH                 = "/../input";
  public static final String MENU_ELEMENT_NONE_XPATH             = "//ul/li[@data-value='_none_']";
  public static final String DROP_DOWN_ITEM_XPATH                = "//*[@role='listbox']/li";
  public static final String LISTBOX_XPATH                       = "//*[@role='listbox']";
  public static final String SELECTED_DROPDOWN_VALUE             = "//*[@aria-selected='true']";
  public static final String GET_TEXT_FROM_TEXT_FIELD_PATTERN    = "//*[text()='%s']/../../input";
  public static final String TEXT_FIELD_BY_TEST_ID_PATTERN       = "//input[@test-id='%s']";
  public static final String TEXT_FIELD_LABEL_BY_TEST_ID_PATTERN = "//input[@test-id='%s']/../label";
  public static final String VALUE                               = "value";
  public static final int    EXP_IETMS_NUMBER                    = 0;
  public static final String MENU_ELEMENTS_ATTRIBUTE             = "data-value";
  public static final String CLOSE_DROPDOWN_WINDOW_XPATH         = "//*[@class='MuiPopover-root']";

  public AddOrderPage(WebDriver driver)
  {
    super(driver);
  }

  public ViewOrderPage clickContinueButton()
  {
    WebElementHelper.waitUntilNumberOfElementsLessThanExpResultByXpath(driver, CLOSE_DROPDOWN_WINDOW_XPATH, 1);
    WebElement element = WebElementHelper.getElement(driver, BUTTON_CONTINUE_XPATH);
    TestLog.step("Try to click continue button");
    element.click();
    return new ViewOrderPage(driver);
  }

  public ViewOrderPage clickResetAndContinueButton()
  {
    clickDropdownButton();
    WebElement element = WebElementHelper.getElement(driver, RESET_CONTENT_AND_CONTINUE_BTN);
    WebElementHelper.clickButton("reset content and continue", element);
    return new ViewOrderPage(driver);
  }

  private ViewOrderPage clickDropdownButton()
  {
    WebElement element = WebElementHelper.getElement(driver, BUTTON_DROPDOWN_XPATH);
    WebElementHelper.clickButton("dropdown", element);
    return new ViewOrderPage(driver);
  }

  public ConnectedPage clickCancelButton()
  {
    WebElement element = WebElementHelper.getElement(driver, BUTTON_CANCEL_XPATH);
    WebElementHelper.clickButton("cancel", element);
    return new ConnectedPage(driver);
  }

  public static void openDropDownListByName(WebDriver driver, String fieldName)
  {
    String labelXpath = String.format(LABEL_DROPDOWN_PATTERN, fieldName);
    ActionsHelper.scrollToWebElement(driver, labelXpath);
    WebElement linkElement = WebElementHelper.getElement(driver, labelXpath + LINK_ELEMENT_XPATH);
    DropDownListHelper.openDropdownList(driver, fieldName, linkElement);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, LISTBOX_XPATH, EXP_IETMS_NUMBER);
  }

  public static void closeDropDownListByOffset(WebDriver driver)
  {
    ActionsHelper.moveMouseToOffsetAndClick(driver, -450, 0);
  }

  public static void selectItemFromDropDownList(WebDriver driver, String fieldValue, String fieldName)
  {
    String xpath = String.format(CHOOSE_FROM_MENU_PATTERN, fieldValue);
    WebElement menuElement = WebElementHelper.getElementWithoutWaiting(driver, xpath);
    ActionsHelper.sleep(1000);

    if (menuElement == null)
    {
      TestLog.step("Dropdown set to none");
      menuElement = WebElementHelper.getElementWithoutWaiting(driver, MENU_ELEMENT_NONE_XPATH);

      DropDownListHelper.selectValueFromDropdownList(driver, "None", menuElement, fieldName);
    }
    ActionsHelper.sleep(1000);

    DropDownListHelper.selectValueFromDropdownList(driver, fieldValue, menuElement, fieldName);
  }

  public static List<String> getItemsFromDropDownList(WebDriver driver)
  {
    ArrayList<String> menuOptions = new ArrayList<String>();
    List<WebElement> menuOptionElements = WebElementHelper.getElements(driver, DROP_DOWN_ITEM_XPATH);
    for (WebElement el : menuOptionElements)
    {
      String optionValue = el.getText();
      menuOptions.add(optionValue);
    }
    return menuOptions;

  }

  public String getSelectedValueFromDropdown(WebDriver driver, String dropDownName)
  {
    openDropDownListByName(driver, dropDownName);
    WebElement el = WebElementHelper.getElement(driver, SELECTED_DROPDOWN_VALUE);
    String selectedValue = WebElementHelper.getTextFromWebElement(driver, "dropdown", el);
    WebElement dropdown = WebElementHelper.getElement(driver, LISTBOX_XPATH);
    el.sendKeys(Keys.ESCAPE);
    WebElementHelper.waitUntilElemDisappear(driver, WebElementHelper.HOW_LONG_TO_WAIT_IN_SECONDS, dropdown);
    TestLog.step("Received selected value  [" + selectedValue + "] from dropdown list");

    return selectedValue;
  }

  public void enterTextField(String fieldLabel, String text, String title)
  {
    String xpath = String.format(LABEL_PATTERN, fieldLabel);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, xpath, 0);
    ActionsHelper.scrollToWebElement(driver, xpath);
    WebElement input = WebElementHelper.getElement(driver, xpath + INPUT_ELEMENT_XPATH);
    WebElementHelper.enterTextToTextField(title, text, input);
  }

  public boolean chooseValueFromMultiSelect(String fieldLabel, String fieldValue)
  {
    boolean hasItem = false;
    AddOrderPage.openDropDownListByName(driver, fieldLabel);
    List<String> menuOptions = AddOrderPage.getItemsFromDropDownList(driver);
    for (String s : menuOptions)
    {
      if (s.compareTo(fieldValue) == 0)
      {
        AddOrderPage.selectItemFromDropDownList(driver, fieldValue, fieldLabel);
        AddOrderPage.closeDropDownListByOffset(driver);
        hasItem = true;
        break;
      }
    }
    return hasItem;
  }

  public void chooseDatePicker(String fieldLabel, String text)
  {
    String xpath = String.format(LABEL_PATTERN, fieldLabel);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, xpath, 0);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, xpath + LINK_ELEMENT_XPATH, 0);
    ActionsHelper.scrollToWebElement(driver, xpath + LINK_ELEMENT_XPATH);
    WebElement datePickerElement = WebElementHelper.getElement(driver, xpath + LINK_ELEMENT_XPATH);
    DatePickerHelper.selectDateByVisibleText(driver, datePickerElement, text, "Choose date from '" + fieldLabel + "' failed");
  }

  public void enterTextFieldByTestId(String orderTestId, String orderId)
  {
    String xpath = String.format(TEXT_FIELD_BY_TEST_ID_PATTERN, orderTestId);
    WebElement inputElement = WebElementHelper.getElement(driver, xpath);

    String labelXpath = String.format(TEXT_FIELD_LABEL_BY_TEST_ID_PATTERN, orderTestId);
    WebElement labelElement = WebElementHelper.getElement(driver, labelXpath);
    String orderIdLabel = labelElement.getText();

    WebElementHelper.clearInputField(inputElement);
    WebElementHelper.enterTextToTextField(orderIdLabel, orderId, inputElement);

  }

  public String getTextFromTextField(String fieldLabel)
  {
    String xpath = String.format(GET_TEXT_FROM_TEXT_FIELD_PATTERN, fieldLabel);
    WebElement element = WebElementHelper.getElement(driver, xpath);
    String text = element.getAttribute(VALUE);
    TestLog.step("Recieved text [" + text + "] from field [" + fieldLabel + "]");
    return text;
  }

  public String getTextFromTextFieldByTestId(String orderTestId)
  {
    String xpath = String.format(TEXT_FIELD_BY_TEST_ID_PATTERN, orderTestId);
    WebElement fieldElement = WebElementHelper.getElement(driver, xpath);
    String text = fieldElement.getAttribute(VALUE);

    String labelXpath = String.format(TEXT_FIELD_LABEL_BY_TEST_ID_PATTERN, orderTestId);
    WebElement labelElement = WebElementHelper.getElement(driver, labelXpath);
    String orderIdLabel = labelElement.getText();
    TestLog.step("Received text [" + text + "] from field [" + orderIdLabel + "]");
    return text;
  }
}
