package com.company.automation.testautomation.pages.umh.connected;

import com.company.automation.automationframework.exceptions.general.PageValidationException;
import com.company.automation.automationframework.testlog.TestLog;
import com.company.automation.testautomation.helpers.connected.ConnectedHelper;
import com.company.automation.testautomation.helpers.general.selenium.DropDownListHelper;
import com.company.automation.testautomation.helpers.general.selenium.WebElementHelper;
import com.company.automation.testautomation.pages.umh.NavigationBarAndFooterTemplatePage;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ViewOrderPage extends NavigationBarAndFooterTemplatePage
{
  public static final String SUBMIT_BUTTON_XPATH           = "//*[@id='link_Submit']";
  public static final String BACK_TO_INTERVIEW_BTN         = "//*[@class='back-interview-action']";
  public static final String DROPDOWN_CONTENT_LOADER       = "//*[@data-content-piece-id='drop-down-menu-content-1']";
  public static final String SAVE_BUTTON_XPATH             = "//*[@id='link_Save']";
  public static final String CANCEL_BUTTON_XPATH           = "//*[@id='link_Cancel']";
  public static final String DATA_CONTENT_PIECE_ID_PATTERN = "//*[@data-content-piece-id='%s']";
  public static final String DATA_CONTENT_DROPDOWN_PATTERN = "//span[contains(text(),'%s')]//var[@type='15']//span[text()='%s']";
  public static final String DATA_CONTENT_DROPDOWN_OPENED  = "//div[@id='contentMenuSelectContainer']";
  public static final String CHOOSE_FROM_DROPDOWN_PATTERN  = "//*[@class='contentMenuSelectValueContainer ']//*[contains(text(), '%s')]";
  public static final String GET_CURRENT_DROPDOWN_VALUE    = "//*[@class='mceContentMenuValue']";
  public static final String DATE_DOCUMENT_AREA_XPATH      = "//*[@data-content-piece-id='span-content-26']";
  public static final String PROOF_BTN_XPATH               = "//*[@id='proof-action']";
  public static final String PREPARE_PDF_INDICATOR         = "//*[@class='btn dropdown-toggle dropdown-toggle-split btn-outline-dark complete']";
  public static final String DOWNLOAD_PDF_BTN              = "//*[@id='proof-pdf-download']";
  public static final String LOAD_PAGE_LABEL_XPATH         = "//*[@id='loading-overlay']";

  public ViewOrderPage(WebDriver driver)
  {
    super(driver);
  }

  public ConnectedPage clickSubmitBtn()
  {
    ConnectedHelper.clickButton(driver, "submit", SUBMIT_BUTTON_XPATH);
    return new ConnectedPage(driver);
  }

  public AddOrderPage clickBackToInterviewBtn()
  {
    ConnectedHelper.clickButton(driver, "back to interview", BACK_TO_INTERVIEW_BTN);
    return new AddOrderPage(driver);
  }

  public ConnectedPage clickSaveBtn()
  {
    ConnectedHelper.clickButton(driver, "save", SAVE_BUTTON_XPATH);
    return new ConnectedPage(driver);
  }

  public ConnectedPage clickCancelBtn()
  {
    ConnectedHelper.clickButton(driver, "cancel", CANCEL_BUTTON_XPATH);
    return new ConnectedPage(driver);
  }

  public void setDropdownDataContent(String title, String dropDownValue)
  {
    try
    {
      ConnectedHelper.waitUntilPageLoadComplete(driver);
      WebElementHelper.waitForJavascriptDone(driver);

      String[] splitTitle = title.split("#");
      String preTitle = "";
      if (splitTitle.length == 2)
      {
        preTitle = splitTitle[0];
        title = splitTitle[1];
      }

      boolean dropdown_exists = WebElementHelper.isTextDisplayed(driver, title);

      if (dropdown_exists == true)
      {
        TestLog.debug("Page is loaded");
      } else
      {
        TestLog.debug("Page is not loaded");

        throw new PageValidationException("Page is not loaded");
      }

      String dropDownXpath = String.format(DATA_CONTENT_DROPDOWN_PATTERN, preTitle, title);
      WebElement dropDown = WebElementHelper.getElement(driver, dropDownXpath);
      DropDownListHelper.openDropdownList(driver, title, dropDown);

      WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, DATA_CONTENT_DROPDOWN_OPENED, 0);
      String dropDownValueXpath = String.format(CHOOSE_FROM_DROPDOWN_PATTERN, dropDownValue);
      WebElement el = WebElementHelper.getElement(driver, dropDownValueXpath);
      ConnectedHelper.clickButton(driver, " [" + dropDownValue + "] value", dropDownValueXpath);
    } catch (TimeoutException e)
    {
      TestLog.debug("Timeout exception");
      throw new PageValidationException("Timeout exception");
    }
  }

  public String getDateFromDocumentArea(WebDriver driver)
  {
    WebElement dateElement = WebElementHelper.getElement(driver, DATE_DOCUMENT_AREA_XPATH);
    String date = dateElement.getText();
    TestLog.step("Get [" + date + "] from date document area field");
    return date;
  }

  public void setDateFromDocumentArea(WebDriver driver, String date)
  {
    WebElement dateElement = WebElementHelper.getElement(driver, DATE_DOCUMENT_AREA_XPATH);
    WebElementHelper.enterTextToTextField("date", date, dateElement);
  }

  public void clickProofButton()
  {
    ConnectedHelper.clickButton(driver, "proof", PROOF_BTN_XPATH);
  }

  public void clickPdfIndicator()
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpathWithCustomWait(driver, ConnectedHelper.HOW_LONG_TO_WAIT_IN_SECONDS_PDF, PREPARE_PDF_INDICATOR, 0);
    WebElementHelper.waitUntilElemDisappear(driver, ConnectedHelper.HOW_LONG_TO_WAIT_IN_SECONDS_PDF, LOAD_PAGE_LABEL_XPATH);
    ConnectedHelper.clickButton(driver, "prepare pdf indicator", PREPARE_PDF_INDICATOR);
  }

  public void clickDownloadPDF()
  {
    WebElementHelper.waitUntilElementToBeClickable(driver, DOWNLOAD_PDF_BTN);

    ConnectedHelper.clickButton(driver, "download", DOWNLOAD_PDF_BTN);
  }
}
