package com.company.automation.testautomation.pages.umh;

import com.company.automation.automationframework.pageengine.Page;
import com.company.automation.automationframework.testlog.TestLog;
import com.company.automation.testautomation.constants.SystemConstants;
import com.company.automation.testautomation.enums.umh.TouchpointContentViewPanelValueEnum;
import com.company.automation.testautomation.helpers.general.OperationalSystemHelper;
import com.company.automation.testautomation.helpers.general.selenium.ActionsHelper;
import com.company.automation.testautomation.helpers.general.selenium.WebElementHelper;
import com.company.automation.testautomation.helpers.general.selenium.WindowsActionsHelper;
import com.company.automation.testautomation.pages.umh.connected.ConnectedPage;
import com.company.automation.testautomation.pages.umh.content.content.ImageLibraryPage;
import com.company.automation.testautomation.pages.umh.content.content.SmartCanvasPage;
import com.company.automation.testautomation.pages.umh.content.content.SmartTextPage;
import com.company.automation.testautomation.pages.umh.content.styles.ListStylesPage;
import com.company.automation.testautomation.pages.umh.content.styles.ParagraphStylePage;
import com.company.automation.testautomation.pages.umh.content.styles.TextStylesPage;
import com.company.automation.testautomation.pages.umh.data.*;
import com.company.automation.testautomation.pages.umh.data.resources.DataResourcesPage;
import com.company.automation.testautomation.pages.umh.data.variables.VariablesPage;
import com.company.automation.testautomation.pages.umh.insert.InsertSchedulesPage;
import com.company.automation.testautomation.pages.umh.insert.InsertSchedulesSetupPage;
import com.company.automation.testautomation.pages.umh.insert.InsertsPage;
import com.company.automation.testautomation.pages.umh.report.ReportsPage;
import com.company.automation.testautomation.pages.umh.target.TargetGroupsPage;
import com.company.automation.testautomation.pages.umh.target.TargetingRulesPage;
import com.company.automation.testautomation.pages.umh.task.ChangesPage;
import com.company.automation.testautomation.pages.umh.task.SystemTasksPage;
import com.company.automation.testautomation.pages.umh.task.TasksPage;
import com.company.automation.testautomation.pages.umh.test.SimulationsPage;
import com.company.automation.testautomation.pages.umh.test.TestConnectedPage;
import com.company.automation.testautomation.pages.umh.test.TestsPage;
import com.company.automation.testautomation.pages.umh.touchpoint.*;
import com.company.automation.testautomation.pages.umh.touchpointSetup.SyncPage;
import com.company.automation.testautomation.pages.umh.touchpointSetup.zones.ZonesSetupPage;
import com.company.automation.testautomation.pages.umh.touchpoints.MessagesPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

import static com.company.automation.testautomation.pages.umh.TableActionsPanel.MORE_BUTTON_XPATH;
import static com.company.automation.testautomation.pages.umh.touchpointSetup.zones.ZonesSetupPage.SELECT_ZONE_LIST;

public class NavigationBarAndFooterTemplatePage extends Page
{
  public static final  String TOUCHPOINTS_PAGE_TITLE                     = "Messagepoint - Touchpoints";
  public static final  String GOOGLE_WAFFLE_XPATH                        = "//*[@aria-label='Add-on Modules']";
  public static final  String USER_INFO_TAB_XPATH                        = "//*[@id='userInfo']";
  public static final  String TOUCHPOINT_TAB_XPATH                       = "//*[@id='dropdown13']";
  public static final  String TASK_TAB_XPATH                             = "//*[@id='dropdown1']";
  public static final  String TARGET_TAB_XPATH                           = "//*[@id='dropdown3']";
  public static final  String CONTENT_TAB_XPATH                          = "//*[@id='dropdown2']";
  public static final  String INSERT_TAB_XPATH                           = "//*[@id='dropdown12']";
  public static final  String TEST_TAB_XPATH                             = "//*[@id='dropdown9']";
  public static final  String REPORT_TAB_XPATH                           = "//*[@id='dropdown6']";
  public static final  String DATA_TAB_XPATH                             = "//*[@id='dropdown10']";
  public static final  String ALERT_STATUS_XPATH                         = "//div[contains(@class, 'alert')]//strong";
  public static final  String ALERT_MESSAGES_LI_XPATH                    = "//div[contains(@class, 'alert')]/div//li";
  public static final  String ALERT_MESSAGES_SPAN_XPATH                  = "//div[contains(@class, 'alert')]/div//span";
  public static final  String ALERT_MAIN_DIV_XPATH                       = "//div[contains(@class, 'alert')]";
  public static final  String ALERT_CLOSE_BUTTON                         = "//div[contains(@class, 'alert')]//button";
  public static final  String INSTANCES_OPENED                           = "//*[@class='dropdown-header dropdown-item dropdown-toggle text-capitalize dropdown-flexblock']";
  public static final  String CONNECTED_APP_MENU_ITEM                    = "//*[@id='connectedMenuItem']";
  public static final  String HOME_BUTTON_XPATH                          = "//*[@id='homeButton']";
  public static final  String CONNECTED                                  = "Connected";
  public static final  String TOUCHPOINTS                                = "Touchpoints";
  public static final  String TOUCHPOINTS_COLLECTIONS                    = "Touchpoint Collections";
  public static final  String OUTPUT_TAGS                                = "Output Tags";
  public static final  String DELIVERY_EVENTS                            = "Delivery Events";
  public static final  String TASKS                                      = "Tasks";
  public static final  String SYSTEM_TASKS                               = "System Tasks";
  public static final  String USER_FIRST_LAST_NAME_FIELD_XPATH           = "//*[@id='user-name']";
  public static final  String CURRENT_BRANCH_FIELD_XPATH                 = "//*[@id='current-branch']";
  public static final  String CURRENT_INSTANCE_FIELD__XPATH              = "//*[@id='current-instance']";
  public static final  String CHOOSE_TOUCHPOINT_PANEL                    = "//*[@aria-label='Current touchpoint']";
  public static final  String TOUCHPOINT_FRAME                           = "//*[@class='iFrameMenuFrame']";
  public static final  String CURRENT_TOUCHPOINT                         = "//*[@class='touchpointContextName mr-auto text-left w-100 text-nowrap text-truncate']";
  public static final  String CONTENT_TAB_LIST_OPTION_XPATH              = "//div[contains(@class, 'show')]//a[text()='List']";
  private static final String NOTIFICATION_BTN_XPATH                     = "//*[@class='indicator fad fa-lg fa-bell fa-swap-opacity']";
  private static final String CLEAR_NOTIFICATION_BUTTON_XPATH            = "//*[@data-taskstatus='complete']//*[@class='far fa-trash-alt']";
  private static final String TOUCHPOINT_SETUP_DROPDOWN_SYNC_OPTION_NAME = "Sync";
  private static final String TOUCHPOINT_SETUP_DROPDOWN_ZONE_OPTION_NAME = "Zones";
  private static final String INSTANCE_DROPDOWN_XPATH                    = "//*[@aria-controls='instances']";
  private static final String CHOOSE_INSTANCE_BY_NAME_PATTERN            = "//*[@id='instances']//*[contains(text(), '%s')]";
  private static final String TOUCHPOINT_DROPDOWN_OPTION_PATTERN         = "//div[@searchname='%s']";
  private static final String GUID_PATTERN                               = "//*[@data-guid='%s']";
  private static final String ITEM_FROM_DATA_PATTERN                     = "//*[@class='dropdown-menu dropdown-custom show']//*[text()='%s']";
  private static final String MASTER                                     = "//*[@id='contextBar_currentSelectionName']";
  private static final String SWITCH_MASTER                              = "//*[@class='breadcrumb-item text-dark']";
  private static final String EDIT_CHANNEL_CONFIGURATION_BTN_XPATH       = "//*[@id='channelConnectorEditBtn_button']";
  private static final String TOUCHPOINT_SETUP_BTN_XPATH                 = "//*[@id='touchpointSetupActions']";
  private static final String TOUCHPOINT_SETUP_OPTION_PATTERN            = "//div[@class='touchpointSetupActionsContainer']//li[a[contains(.,'%s')]]";
  private static final String TOUCHPOINT_SETUP_IFRAME_ID                 = "iFrameMenuFrame_touchpointSetupActions";
  private static final String PAGE_LOADER_PATTERN                        = "//h1[@class='h4 pb-2 mb-4' and text()='%s']";
  private static final String OPEN_MORE_TAB                              = "//*[@id='dropdownMore']";
  private static final String DATA_TAB_FROM_MORE                         = "//*[@id='copy_dropdown10']";
  public NavigationBarAndFooterTemplatePage(WebDriver driver)
  {
    super(driver);
  }

  public MessagesPage openHomePage()
  {
    WindowsActionsHelper.switchToDefaultContent(driver);
    WebElementHelper.waitForJavascriptDone(driver);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, HOME_BUTTON_XPATH, 0);
    WebElementHelper.waitUntilElementToBeClickable(driver, HOME_BUTTON_XPATH);
    WebElementHelper.clickButton(driver, "home",HOME_BUTTON_XPATH);

    MessagesPage messagesPage = new MessagesPage(driver);
    messagesPage = (MessagesPage) messagesPage.switchToTouchpointContentByPageName(TouchpointContentViewPanelValueEnum.MESSAGES);
    WebElementHelper.waitForTableToLoad(driver);

    return messagesPage;
  }

  public void openMasterMpBranch()
  {
    boolean masterExists = WebElementHelper.isElementDisplayed(driver, MASTER, 5);
    if (!masterExists || WebElementHelper.getTextFromWebElement(driver, "master", WebElementHelper.getElement(driver, MASTER)).compareTo("Master") == 0)
    {
      return;
    }
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, SWITCH_MASTER, 0);
    WebElementHelper.clickElement(driver, "master branch", SWITCH_MASTER);
  }

  public MessagesPage openTouchpointsPage()
  {
    WebElementHelper.clickElement(driver, "touchpoint tab", TOUCHPOINT_TAB_XPATH);

    TestLog.step("Try to click touchpoint tab");
    WebElementHelper.findAndClickElementByText(driver, TOUCHPOINTS);
    return new MessagesPage(driver);
  }

  public TouchpointCollectionsPage openTouchpointCollectionsPage()
  {
    WebElementHelper.clickElement(driver, "touchpoint tab", TOUCHPOINT_TAB_XPATH);

    TestLog.step("Try to click Touchpoint Collections item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, TOUCHPOINTS_COLLECTIONS);
    return new TouchpointCollectionsPage(driver);
  }

  public OutputTagsPage openOutputTagsPage()
  {
    WebElementHelper.clickElement(driver, "touchpoint tab", TOUCHPOINT_TAB_XPATH);

    TestLog.step("Try to click Output Tags item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, OUTPUT_TAGS);
    return new OutputTagsPage(driver);
  }

  public DeliveryEventsPage openDeliveryEventsPage()
  {
    WebElementHelper.clickButton(driver, "touchpoint tab", TOUCHPOINT_TAB_XPATH);

    TestLog.step("Try to click Delivery Events item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, DELIVERY_EVENTS);
    return new DeliveryEventsPage(driver);
  }

  public TasksPage openTasksPage()
  {
    WebElementHelper.clickButton(driver, "task tab", TASK_TAB_XPATH);

    TestLog.step("Try to click Tasks item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, TASKS);
    return new TasksPage(driver);
  }

  public SystemTasksPage openSystemTasks()
  {
    WebElementHelper.clickElement(driver, "task tab", TASK_TAB_XPATH);

    TestLog.step("Try to click System Tasks item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, SYSTEM_TASKS);
    return new SystemTasksPage(driver);
  }

  public ChangesPage openChangesPage()
  {
    WebElementHelper.clickElement(driver, "task tab", TASK_TAB_XPATH);

    TestLog.step("Try to click Changes item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Changes");
    return new ChangesPage(driver);
  }

  public TargetGroupsPage openTargetGroupsPage()
  {
    WebElementHelper.clickElement(driver, "Target", TARGET_TAB_XPATH);
    TestLog.subStep("Try to click Target Groups item from dropdown menu");
    WebElementHelper.findAndClickElementByText(driver, "Target Groups");
    WebElementHelper.waitUntilElementWillBePresent(driver, TargetGroupsPage.TARGET_GROUPS_LIST_PROCESSING_XPATH);
    WebElementHelper.waitUntilInvisibilityOfElementLocated(driver, TargetGroupsPage.TARGET_GROUPS_LIST_PROCESSING_XPATH);

    return new TargetGroupsPage(driver);
  }

  public TargetingRulesPage openTargetingRulesPage()
  {
    WebElementHelper.clickElement(driver, "Target", TARGET_TAB_XPATH);
    TestLog.subStep("Try to click Targeting Rules item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Targeting Rules");
    WebElementHelper.waitUntilElementWillBePresent(driver, TargetingRulesPage.TARGETING_RULE_LIST_PROCESSING_XPATH);
    WebElementHelper.waitUntilInvisibilityOfElementLocated(driver, TargetingRulesPage.TARGETING_RULE_LIST_PROCESSING_XPATH);
    return new TargetingRulesPage(driver);
  }

  public TextStylesPage openTextStylesPage()
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, CONTENT_TAB_XPATH, 0);
    WebElementHelper.clickElement(driver, "[Content] tab", CONTENT_TAB_XPATH);
    TestLog.step("Try to click [Text] item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Text");
    return new TextStylesPage(driver);
  }

  public ParagraphStylePage openParagraphStylePage()
  {
    WebElementHelper.clickElement(driver, "Content tab", CONTENT_TAB_XPATH);
    TestLog.step("Try to click Paragraph item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Paragraph");
    return new ParagraphStylePage(driver);
  }

  public ListStylesPage openListStyleTableSegmentPage()
  {
    WebElementHelper.clickElement(driver, "Content tab", CONTENT_TAB_XPATH);

    WebElementHelper.waitUntilElementToBeClickable(driver, CONTENT_TAB_LIST_OPTION_XPATH);
    WebElementHelper.clickButton(driver, "List", CONTENT_TAB_LIST_OPTION_XPATH);
    return new ListStylesPage(driver);
  }

  public SmartTextPage openSmartTextPage()
  {
    WebElementHelper.clickElement(driver, "Content tab", CONTENT_TAB_XPATH);

    TestLog.step("Try to click Smart Text item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Smart Text");
    String xpath = String.format(PAGE_LOADER_PATTERN,"Smart Text");
    ActionsHelper.sleep(3000); //firefox load java script long time...
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, xpath,0);
    return new SmartTextPage(driver);
  }

  public SmartCanvasPage openSmartCanvasPage()
  {
    WebElementHelper.clickElement(driver, "Content tab", CONTENT_TAB_XPATH);

    TestLog.step("Try to click Smart Canvas item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Smart Canvas");
    return new SmartCanvasPage(driver);
  }

  public ImageLibraryPage openImageLibraryPage()
  {
    WebElementHelper.clickElement(driver, "Content tab", CONTENT_TAB_XPATH);

    TestLog.step("Try to click Image Library item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Image Library");
    String xpath = String.format(PAGE_LOADER_PATTERN, "Image Library");
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, xpath,0);
    return new ImageLibraryPage(driver);
  }

  public InsertsPage openInsertsPage()
  {
    WebElementHelper.clickElement(driver, "insert tab", INSERT_TAB_XPATH);

    TestLog.step("Try to click Inserts item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Inserts");
    return new InsertsPage(driver);
  }

  public InsertSchedulesPage openInsertSchedulesPage()
  {
    WebElementHelper.clickElement(driver, "insert tab", INSERT_TAB_XPATH);

    TestLog.step("Try to click Insert Schedules item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Insert Schedules");
    return new InsertSchedulesPage(driver);
  }

  public InsertSchedulesSetupPage openInsertSchedulesSetupPage()
  {
    WebElementHelper.clickElement(driver, "insert tab", INSERT_TAB_XPATH);

    TestLog.step("Try to click Insert Schedules Setup item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Insert Schedules Setup");
    return new InsertSchedulesSetupPage(driver);
  }

  public TestsPage openTestsPage()
  {
    WebElementHelper.clickElement(driver, "test tab", TEST_TAB_XPATH);

    WebElementHelper.findAndClickElementByText(driver, "Tests");
    return new TestsPage(driver);
  }

  public SimulationsPage openSimulationsPage()
  {
    WebElementHelper.clickElement(driver, "test tab", TEST_TAB_XPATH);

    TestLog.step("Try to click Simulations item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Simulations");
    return new SimulationsPage(driver);
  }

  public ReportsPage openReportsPage()
  {
    WebElementHelper.clickElement(driver, "report tab", REPORT_TAB_XPATH);

    TestLog.step("Try to click Reports item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Reports");
    return new ReportsPage(driver);
  }

  public DataSourcesPage openDataSourcesPage()
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, DATA_TAB_XPATH, 0);
    WebElementHelper.clickElement(driver, "data", DATA_TAB_XPATH);
    String xpath = String.format(ITEM_FROM_DATA_PATTERN, "Data Sources");
    WebElementHelper.clickElement(driver, "Data Sources", xpath);
    return new DataSourcesPage(driver);
  }

  public DataGroupsPage openDataGroupsPage()
  {
    WebElementHelper.clickElement(driver, "data tab", DATA_TAB_XPATH);

    TestLog.step("Try to click Data Groups item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Data Groups");
    return new DataGroupsPage(driver);
  }

  public DataCollectionsPage openDataCollectionsPage()
  {
    WebElementHelper.clickElement(driver, "data tab", DATA_TAB_XPATH);

    TestLog.step("Try to click Data Collections item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Data Collections");
    return new DataCollectionsPage(driver);
  }

  public DataFilesPage openDataFilesPage()
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, DATA_TAB_XPATH, 0);
    WebElementHelper.clickElement(driver, "data tab", DATA_TAB_XPATH);

    TestLog.step("Try to click Data Files item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Data Files");
    String xpathLoad = String.format(PAGE_LOADER_PATTERN, "Data Files");
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver,xpathLoad,0);

    return new DataFilesPage(driver);
  }

  public DataResourcesPage openDataResourcesPage()
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, DATA_TAB_XPATH, 0);
    WebElementHelper.clickElement(driver, "data tab", DATA_TAB_XPATH);

    TestLog.step("Try to click Data Resources item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Data Resources");
    String xpath = String.format(PAGE_LOADER_PATTERN,"Data Resources");
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver,xpath,0);
    return new DataResourcesPage(driver);
  }

  public VariablesPage openVariablesPage()
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, DATA_TAB_XPATH, 0);
    WebElementHelper.waitUntilElementToBeClickable(driver,DATA_TAB_XPATH);
    WebElementHelper.clickElement(driver,"data",DATA_TAB_XPATH);
    TestLog.step("Try to click Variables item from drop down menu");
    String xpath = String.format(ITEM_FROM_DATA_PATTERN, "Variables");
    WebElementHelper.clickElement(driver, "variables", xpath);
    String xpathLoad = String.format(PAGE_LOADER_PATTERN, "Variables");
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver,xpathLoad,0);

    return new VariablesPage(driver);
  }

  public SelectorGroupsPage openSelectorGroupsPage()
  {
    WebElementHelper.clickElement(driver, "data tab", DATA_TAB_XPATH);

    TestLog.step("Try to click Selector Groups item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Selector Groups");
    return new SelectorGroupsPage(driver);
  }

  public ExternalEventPage openExternalEventPage()
  {
    WebElementHelper.clickElement(driver, "data tab", DATA_TAB_XPATH);

    TestLog.step("Try to click External Event item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "External Event");
    return new ExternalEventPage(driver);
  }

  public LookupTablesPage openLookupTablesPage()
  {
    WebElementHelper.clickElement(driver, "data tab", DATA_TAB_XPATH);

    TestLog.step("Try to click Lookup Tables item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Lookup Tables");
    return new LookupTablesPage(driver);
  }

  public MetadataTemplatesPage openMetadataTemplatesPage()
  {
    WebElementHelper.clickElement(driver, "data tab", DATA_TAB_XPATH);

    TestLog.step("Try to click Metadata Templates item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Metadata Templates");
    return new MetadataTemplatesPage(driver);
  }

  public TagCloudPage openTagCloudPage()
  {
    WebElementHelper.clickElement(driver, "data tab", DATA_TAB_XPATH);

    TestLog.step("Try to click Tag Cloud item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, "Tag Cloud");
    return new TagCloudPage(driver);
  }

  public String getAlertFullMessage()
  {
    String finalString = new String();
    String status = getAlertStatus();
    List<String> msgList = getAlertMessages();

    finalString = finalString.concat(status + "\n");

    for (String str : msgList)
    {
      finalString = finalString.concat(str + "\n");
    }

    return finalString;
  }

  public String getAlertStatus()
  {
    WebElement el = WebElementHelper.getElement(driver, ALERT_STATUS_XPATH);
    String str = el.getText();
    return str.trim();
  }

  public List<String> getAlertMessages()
  {
    List<WebElement> elements = new ArrayList<>();
    List<String> msgList = new ArrayList<>();

    int li = driver.findElements(By.xpath(ALERT_MESSAGES_LI_XPATH)).size();
    int span = driver.findElements(By.xpath(ALERT_MESSAGES_SPAN_XPATH)).size();
    int div = driver.findElements(By.xpath(ALERT_MAIN_DIV_XPATH)).size();

    if (li > 0)
      elements = WebElementHelper.getElementsByXpathDefaultWaiting(driver, ALERT_MESSAGES_LI_XPATH);
    else if (span > 0)
      elements = WebElementHelper.getElementsByXpathDefaultWaiting(driver, ALERT_MESSAGES_SPAN_XPATH);
    else if (div > 0)
      elements = WebElementHelper.getElementsByXpathDefaultWaiting(driver, ALERT_MAIN_DIV_XPATH);

    if (elements.isEmpty())
    {
      TestLog.debug("WARNING: Unsupported alert structure!");
      return null;
    }

    for (WebElement el : elements)
    {
      String txt = el.getText();
      msgList.add(txt);
    }

    return msgList;
  }

  public String getAlertSaveComplete()
  {
    WebElement element = WebElementHelper.getElement(driver, ALERT_MAIN_DIV_XPATH);

    if (element == null)
    {
      TestLog.debug("WARNING: Unsupported Save Complete alert structure!");
      return null;
    }

    String msg = element.getText();

    return msg;
  }

  public void clickAlertCloseButton()
  {
    // next wait for complete page update 2 seconds
    WebElementHelper.waitForJavascriptDoneForSpecificTime(driver, 10);
    boolean res = WebElementHelper.isElementExistsByXpath(driver, ALERT_CLOSE_BUTTON);
    if (res)
    {
      WebElementHelper.clickButton(driver, "Alert close", ALERT_CLOSE_BUTTON);
    }
  }

  public TestConnectedPage openConnectedPageViaTestTab()
  {
    WebElementHelper.clickElement(driver, "data tab", TEST_TAB_XPATH);

    TestLog.step("Try to click Connected item from drop down menu");
    WebElementHelper.findAndClickElementByText(driver, CONNECTED);
    return new TestConnectedPage(driver);
  }

  public ConnectedPage openConnectedAppPageViaGoogleWaffle()
  {
    WebElement googleWaffle = WebElementHelper.getElement(driver, GOOGLE_WAFFLE_XPATH);
    WebElementHelper.waitForElementForSpecificTime(driver, googleWaffle, 5);
    if (googleWaffle == null)
    {
      return null;
    }
    WebElementHelper.clickButton("google waffle", googleWaffle);
    WebElement connectedMenuItem = WebElementHelper.getElement(driver, CONNECTED_APP_MENU_ITEM);
    WebElementHelper.waitForElementForSpecificTime(driver, connectedMenuItem, 5);

    if (connectedMenuItem == null)
    {
      return null;
    }
    WebElementHelper.clickButton("connected app menu", connectedMenuItem);

    return new ConnectedPage(driver);
  }

  public String getUserFirstLastName()
  {
    WebElementHelper.waitForJavascriptDone(driver);
    WebElement el = WebElementHelper.getElement(driver, USER_FIRST_LAST_NAME_FIELD_XPATH);

    if (el == null)
      return "";

    String str = el.getText();
    return str.trim();
  }

  public String getBranchName()
  {
    WebElementHelper.waitForJavascriptDone(driver);
    WebElement el = WebElementHelper.getElement(driver, CURRENT_BRANCH_FIELD_XPATH);

    if (el == null)
      return "";

    String str = el.getText();
    return str.trim();
  }

  public String getInstanceName()
  {
    WebElementHelper.waitForJavascriptDone(driver);
    WebElement el = WebElementHelper.getElement(driver, CURRENT_INSTANCE_FIELD__XPATH);

    if (el == null)
      return "";

    String str = el.getText();
    return str.trim();
  }

  public void chooseTouchpointByName(String name)
  {
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver,CURRENT_TOUCHPOINT,0);
    WebElementHelper.waitForTableToLoad(driver);
    TestLog.step("Try to select Touchpoint by name:[" + name + "]");

    String currentTouchpoint = WebElementHelper.getElement(driver, CURRENT_TOUCHPOINT).getText();
    if (name.compareTo(currentTouchpoint) == 0)
    {
      TestLog.step("Touchpoint:[" + name + "] is successfully selected");
      return;
    }
    WebElementHelper.waitForJavascriptDone(driver);
    WebElementHelper.clickElement(driver, "touchpoint panel", CHOOSE_TOUCHPOINT_PANEL);
    WebElement frameElement = WebElementHelper.getElement(driver, TOUCHPOINT_FRAME);
    WindowsActionsHelper.waitUntilFrameLoadAndSwitch(driver, WebElementHelper.HOW_LONG_TO_WAIT_IN_SECONDS, frameElement);
    String xpath = String.format(TOUCHPOINT_DROPDOWN_OPTION_PATTERN, name);
    WebElementHelper.clickElement(driver, "Touchpoint:[" + name + "] from Touchpoints dropdown", xpath);
    ActionsHelper.sleep(2000);
    WindowsActionsHelper.switchToParentWindow(driver);
    WebElementHelper.waitForTableToLoad(driver);
    TestLog.step("Touchpoint:[" + name + "] is successfully selected");
  }

  public void clickNotificationPanel()
  {
    WebElementHelper.clickButton(driver, "Notification", NOTIFICATION_BTN_XPATH);
  }

  public void clearNotificationItems()
  {
    TestLog.step("Start to clear sync notifications");
    List<WebElement> elements = WebElementHelper.getElements(driver, CLEAR_NOTIFICATION_BUTTON_XPATH);
    elements.forEach(WebElement::click);
  }

  public SyncPage openSyncPage()
  {
    TestLog.step("Start to open Sync Touchpoints page");
    selectTouchpointSetupDropdownOptionByName(TOUCHPOINT_SETUP_DROPDOWN_SYNC_OPTION_NAME);
    WindowsActionsHelper.switchToWindowByTitle(driver, TOUCHPOINT_SETUP_DROPDOWN_SYNC_OPTION_NAME);

    SyncPage syncPage = new SyncPage(driver);
    TestLog.step("Sync Touchpoints page is successfully opened");

    return syncPage;
  }

  public ZonesSetupPage openZonesPage()
  {
    TestLog.step("Start to open Zone page");
    selectTouchpointSetupDropdownOptionByName(TOUCHPOINT_SETUP_DROPDOWN_ZONE_OPTION_NAME);
    ZonesSetupPage zonesSetupPage = new ZonesSetupPage(driver);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, SELECT_ZONE_LIST, 0);
    return zonesSetupPage;
  }

  public WebDriver chooseInstanceByName(String instanceName, String username, String password)
  {
    WindowsActionsHelper.switchToDefaultContent(driver);
    ActionsHelper.sleep(2000);
    String currentInstance = getCurrentInstance();
    if (!currentInstance.contains(instanceName))
    {
      TestLog.step("Current instance:[" + currentInstance + "] should be changed to: [" + instanceName + "]");
      ActionsHelper.sleep(2000);
      WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, INSTANCE_DROPDOWN_XPATH, 0);
      WebElementHelper.clickElement(driver, "instance list", INSTANCE_DROPDOWN_XPATH);

      ActionsHelper.sleep(2000);
      WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, INSTANCES_OPENED, 0);
      WebElementHelper.waitForJavascriptDone(driver);

      String xpath = String.format(CHOOSE_INSTANCE_BY_NAME_PATTERN, instanceName);
      WebElementHelper.waitForElementToBeClickable(driver, By.xpath(xpath), 5);
      WebElementHelper.clickElement(driver, "select [" + instanceName + "] instance", xpath);
      WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver,"//*[@class='position-relative box-shadow-4 bg-white rounded']",0);
      InstancePage instancePage = new InstancePage(driver);
      instancePage.enterPassword(password);
      instancePage.clickConfirmButton();
      TestLog.step("Current instance successfully changed to:[" + instanceName + "]");
      WebElementHelper.waitForTableToLoad(driver);
    } else
    {
      WebElementHelper.waitForElementToBeClickable(driver, By.xpath(USER_INFO_TAB_XPATH), 3);
      WebElement userInfoEl = WebElementHelper.getElement(driver, USER_INFO_TAB_XPATH);
      ActionsHelper.moveToElementAndClick(driver, userInfoEl);
    }
    openMasterMpBranch();

    return driver;
  }

  public void chooseInstanceAndTouchpointByName(String insName,String user,String password,String tpName){
    chooseInstanceByName(insName,user,password);
    chooseTouchpointByName(tpName);
  }

  public void chooseInstanceByGuid(String guid)
  {
    TestLog.step("Choose instance by guid [" + guid + "]");
    String xpath = String.format(GUID_PATTERN, guid);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, xpath, 0);
    ActionsHelper.scrollToWebElement(driver, xpath);
    WebElementHelper.clickElement(driver, "select instance", xpath);
  }

  public String getCurrentInstance()
  {
    TestLog.step("Try to get current instance");
    clickUserInfoTab();
    WebElementHelper.waitForElementToBeClickable(driver, By.xpath(INSTANCE_DROPDOWN_XPATH), 3);
    WebElement instanceEl = WebElementHelper.getElement(driver, INSTANCE_DROPDOWN_XPATH);
    String instanceString = instanceEl.getText().toLowerCase();
    String instanceName = instanceString.substring(instanceString.indexOf("(") + 1, instanceString.indexOf(")"));
    TestLog.step("Retrieved current instance name:[" + instanceName + "]");

    return instanceName;
  }

  public void clickUserInfoTab()
  {
    WebElementHelper.waitForElementToBeClickable(driver, By.xpath(USER_INFO_TAB_XPATH), 3);
    WebElement userInfoEl = WebElementHelper.getElement(driver, USER_INFO_TAB_XPATH);
    ActionsHelper.moveToElementAndClick(driver, userInfoEl);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, "//*[@class='nav-item dropdown show']", 0);
  }

  public ConfigureTouchpointPage openConfigureTouchpointPage(String touchpoint)
  {
    chooseTouchpointByName(touchpoint);
    selectTouchpointSetupDropdownOptionByName("Touchpoint");

    return new ConfigureTouchpointPage(driver);
  }

  public ChannelConfigurationPage openChannelConfigurationPage(String touchpoint)
  {
    ConfigureTouchpointPage configureTouchpointPage = openConfigureTouchpointPage(touchpoint);
    WebElementHelper.clickButton(driver, "Edit Channel configuration", EDIT_CHANNEL_CONFIGURATION_BTN_XPATH);

    return new ChannelConfigurationPage(driver);
  }

  public void selectTouchpointSetupDropdownOptionByName(String fieldName)
  {
    TestLog.subStep("Try to select option from Touchpoint Setup dropdown list by name: [" + fieldName + "]");
    ActionsHelper.sleep(5000);

    WebElementHelper.clickElement(driver, "Touchpoint Setup icon", TOUCHPOINT_SETUP_BTN_XPATH);
    WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, "//*[@id='iFrameMenu_touchpointSetupActions']", 0);
    WindowsActionsHelper.switchToFrameById(driver, TOUCHPOINT_SETUP_IFRAME_ID);

    String optionXpath = String.format(TOUCHPOINT_SETUP_OPTION_PATTERN, fieldName);
    WebElementHelper.clickElement(driver, fieldName + " option", optionXpath);
    WindowsActionsHelper.switchToParentFromIframe(driver);
  }
}
