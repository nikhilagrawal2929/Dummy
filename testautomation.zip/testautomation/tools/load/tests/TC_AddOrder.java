package com.company.automation.testautomation.tools.load.tests;

import com.company.automation.automationframework.helpers.PropertiesReaderHelper;
import com.company.automation.automationframework.templates.InitTest;
import com.company.automation.testautomation.helpers.connected.ConnectedHelper;
import com.company.automation.testautomation.helpers.general.selenium.ActionsHelper;
import com.company.automation.testautomation.helpers.umh.LoginHelper;
import com.company.automation.testautomation.pages.umh.LoginPage;
import com.company.automation.testautomation.pages.umh.connected.AddOrderPage;
import com.company.automation.testautomation.pages.umh.connected.ConnectedPage;
import com.company.automation.testautomation.pages.umh.connected.ViewOrderPage;
import com.company.automation.testautomation.pages.umh.touchpoints.MessagesPage;
import com.company.automation.testautomation.tdo.ui.connected.orders.ConnectedOrderTDO;
import com.company.automation.testautomation.tdo.ui.umh.LoginTDO;
import com.company.automation.testautomation.tools.load.LoadTestingHelper;
import org.testng.Reporter;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.concurrent.ThreadLocalRandom;

//@DataSource(source = "com/company/automation/testautomation/tests/ui/connected/data/TC_AddOrder.csv")
public class TC_AddOrder extends InitTest
{
  @Test(alwaysRun = true)
  public void addOrder()
  {
    //test data (Ex: Instead of TestNG dataprovider which takes data from csv file)
    HashMap<String, String> csv = new HashMap();
    csv.put("scenario", "1");
    csv.put("nickname", "natwest-1");
    csv.put("client", "natwest");
    csv.put("test-env", "ta241avi");
    csv.put("generateGoldenVersion", "FALSE");
    csv.put("username", "<username>");
    csv.put("password", "<password>");
    csv.put("domain", "<domain>");
    csv.put("instance", "natwest-development");
    csv.put("order-test-id", "Connected_OrderID");
    csv.put("order-id", "1027193-QKV93");
    csv.put("expectedResult", "TRUE");
    csv.put("actualResult", "FALSE");
    csv.put("ORDER_INTERVIEW_FIELDS_NAMES_SEQUENCE", "Documentsoort#Productgroep#Naam variant PER#Aan?");
    csv.put("ORDER_INTERVIEW_VALUES_SEQUENCE", "Brief#Personenschade#Afspraakbevestiging#Belangenbehartiger");

    int randomNum = ThreadLocalRandom.current().nextInt(1, 11);
    ActionsHelper.sleep(randomNum * 1000);
    System.out.println("Waited for " + randomNum + " seconds before starting the test");

    // Step 1: Set required parameters for order creation.
    String uuid = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("UUID");
    System.out.println("UUID: " + uuid + " Set required parameters for order creation");
    ConnectedOrderTDO connectedOrderTDO = new ConnectedOrderTDO(csv);
    boolean generateGoldenVersion = connectedOrderTDO.getGenerateGoldenVersion();
    PropertiesReaderHelper reader = new PropertiesReaderHelper("maven.properties");
    String env = reader.getProperty("env");
    System.out.println("Environment: " + env);
    System.out.println("UUID: " + uuid + " Use our code as tool: [" + generateGoldenVersion + "]");
    System.out.println("UUID: " + uuid + " Use our code as tool: [" + generateGoldenVersion + "]");

    //Step 2: Login and start to add order.
    System.out.println("UUID: " + uuid + " Login and start to add order");
    System.out.println("UUID: " + uuid + " Start to login to UI application and open connected page via google waffle");
    LoginTDO loginTdo = LoginHelper.setLoginInfo(csv);
    String currentUrl = driver.getCurrentUrl();
    System.out.println("Starting URL: " + currentUrl);
    LoginPage loginPage = new LoginPage(driver);
    loginPage.clickToggleInstanceBtn(driver);
    loginPage.enterCompanyName(driver, loginTdo.getDomain());
    loginPage.enterInstanceInfo(driver, loginTdo.getInstance());
    loginPage.enterUsername(driver, loginTdo.getUser());
    loginPage.enterPassword(driver, loginTdo.getPassword());
    loginPage.clickLoginBtn(driver);
    MessagesPage messagesPage = new MessagesPage(driver);
    System.out.println("UUID: " + uuid +
        " Login procedure successfully completed with next parameters: "
        + "domain: [" + loginTdo.getDomain() + "], "
        + "instance: [" + loginTdo.getInstance() + "], "
        + "user: [" + loginTdo.getUser() + "], "
        + "password: [" + loginTdo.getPassword() + "]");

    ConnectedPage connectedPage = messagesPage.openConnectedAppPageViaGoogleWaffle();
    System.out.println("UUID: " + uuid + " Start to create new order [" + connectedOrderTDO.getNickname() + "]");
    AddOrderPage addOrderPage = connectedPage.clickAddOrderBtn();
    System.out.println("UUID: " + uuid + " Start to enter order fields.");
    addOrderPage.enterTextField(ConnectedHelper.INDICATOR_LABEL, connectedOrderTDO.getIndicator(), ConnectedHelper.INDICATOR_LABEL);
    ConnectedHelper.fillOrderValues(driver, addOrderPage, connectedOrderTDO);
    ViewOrderPage viewOrderPage = addOrderPage.clickContinueButton();

    ConnectedHelper.waitUntilPageLoadComplete(driver);

    System.out.println("UUID: " + uuid + " Start to prepare and download current PDF file");
    viewOrderPage.clickProofButton();
    viewOrderPage.clickPdfIndicator();
    System.out.println(LoadTestingHelper.SUCCESS_RUN_INDICATOR);
    System.out.println("Document has been generated");
    System.out.println("Stress test for Add Order has been completed");
  }
}
