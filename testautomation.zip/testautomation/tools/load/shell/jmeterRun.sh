#!/bin/bash

# Ensure parameters are passed correctly
if [ $# -ne 1 ]; then
    echo "Usage: $0 <time>"
    exit 1
fi

time=$1

# Define timeout_seconds based on ${time}
case $time in
    addOrder1day.jmx)
        timeout_seconds=86415  # 1 day in seconds + 15 sec for finishing JMeter process
        ;;
    addOrder30min.jmx)
        timeout_seconds=1815  # 30 minutes in seconds + 15 sec for finishing JMeter process
        ;;
    addOrder20min.jmx)
        timeout_seconds=1215  # 20 minutes in seconds + 15 sec for finishing JMeter process
        ;;
    addOrder1min.jmx)
        timeout_seconds=75  # 1 minute in seconds + 15 sec for finishing JMeter process
        ;;
    addOrder3min.jmx)
        timeout_seconds=195  # 3 minutes in seconds + 15 sec for finishing JMeter process
        ;;
    addOrder10min.jmx)
        timeout_seconds=615  # 10 minutes in seconds + 15 sec for finishing JMeter process
        ;;
    *)
        echo "Unsupported JMeter test script: ${time}"
        exit 1
        ;;
esac

# Kill any existing loadServerStats.sh processes
pkill -f "loadServerStats.sh"

# Start loadServerStats.sh in the background and capture its PID
nohup /home/jenkins/workspace/LoadRun/src/com/company/automation/testautomation/tools/load/shell/loadServerStats.sh &

# Capture the PID of the loadServerStats.sh process
LOAD_SERVER_STATS_PID=$!

# Clear the JMeter logs directory
rm -f /home/jenkins/load/jmeterLogs/*

# Run JMeter with the specified timeout value
/opt/apache-jmeter-5.6.2/bin/jmeter -n -t "/home/jenkins/workspace/LoadRun/src/com/company/automation/testautomation/tools/load/jmeter/${time}" -l /home/jenkins/load/jmeterLogs/testAutomationOpt.csv &

# Capture the PID of the JMeter process
JMETER_PID=$!

# Wait for JMeter to finish or timeout after $timeout_seconds seconds
(sleep $timeout_seconds && ps -p $JMETER_PID > /dev/null && kill -9 $JMETER_PID) &
WAIT_PID=$!

# Wait for JMeter process to finish or timeout
if ! wait $JMETER_PID; then
    echo "JMeter execution timed out after $timeout_seconds seconds."
    kill -9 $JMETER_PID  # Kill JMeter process if it hasn't already terminated
fi

# JMeter has finished or timed out at this point
# Kill any remaining loadServerStats.sh processes
pkill -f "loadServerStats.sh"

# Wait for loadServerStats.sh process to finish
wait $LOAD_SERVER_STATS_PID

# Get the current timestamp
timestamp=$(date +%Y%m%d%H%M%S)

# Create a new directory with the timestamp in the name
cd /home/jenkins/load/log
mkdir /home/jenkins/workspace/LoadRun/log/JmeterLog

# Copy loadServerStats.txt file to the log dir
cp /home/jenkins/load/JmeterRunner/loadServerStats.txt /home/jenkins/load/jmeterLogs

# Generate ServerLoadTestReport
cd /home/jenkins/workspace/LoadRun
mvn -f pom.xml exec:java -Dexec.mainClass=com.company.automation.testautomation.tools.load.report.SingleServerMainReport -Dexec.args="10.10.105.215 /home/jenkins/load/jmeterLogs /home/jenkins/load/jmeterLogs/loadServerStats.txt"     -Dexec.cleanupDaemonThreads=false
echo ServerLoadTestReport has generated

# Copy the JMeter logs to the new directory
cp /home/jenkins/load/jmeterLogs/* /home/jenkins/workspace/LoadRun/log/JmeterLog

# Example: Continue with additional steps after JMeter execution
echo "JMeter test completed. Continuing with post-processing steps."
