#!/bin/bash
set -x
exec 3>&1 1>>"/home/jenkins/load/jmeterLogs/addOrder1.log" 2>&1
trap "date -Is" DEBUG
cd /home/jenkins/workspace/LoadRun
sudo mvn -f pom.xml exec:java -Dexec.mainClass=com.company.automation.testautomation.tools.load.RunnerForLoadTesting     -Dexec.args="AddOrder com.company.automation.testautomation.tools.load.tests.TC_AddOrder 1"     -Dexec.cleanupDaemonThreads=false
