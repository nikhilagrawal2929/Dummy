package com.company.automation.testautomation.tools.load;

import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import java.util.Arrays;

/**
 * Runner for load testing
 */
public class RunnerForLoadTesting
{
  private static final String BROWSER           = "browser";
  private static final String UI_TEST           = "uiTest";
  private static final String TEST_RUN_ID       = "testRunId";
  private static final String UUID              = "UUID";
  private static final String BROWSER_VALUE     = "chrome";
  private static final String UI_TEST_VALUE     = "true";
  private static final String TEST_RUN_ID_VALUE = "2";
  private static final String SUITE             = "Suite";

  public static void main(String[] args)
  {
    String testName = args[0];
    String testClass = args[1];
    String uuid = args[2];
    //    String testName = "AddOrder";
    //    String testClass = "com.company.automation.testautomation.tools.load.tests.TC_AddOrder";
    //    String uuid = "1";

    System.out.println("Test has been started");
    RunnerForLoadTesting runner = new RunnerForLoadTesting();
    runner.run(testName, testClass, uuid);
    System.out.println("Test has finished");
  }

  public void run(String testName, String clazzName, String uuid)
  {
    Class className = null;
    try
    {
      className = Class.forName(clazzName);
    } catch (ClassNotFoundException e)
    {
      e.printStackTrace();
    }

    XmlClass testClass = new XmlClass();
    testClass.setClass(className);

    XmlSuite suite = new XmlSuite();
    suite.setName(SUITE);

    XmlTest test = new XmlTest(suite);
    test.setName(testName);

    test.addParameter(BROWSER, BROWSER_VALUE);
    test.addParameter(UI_TEST, UI_TEST_VALUE);
    test.addParameter(TEST_RUN_ID, TEST_RUN_ID_VALUE);
    test.addParameter(UUID, uuid);
    test.setXmlClasses(Arrays.asList(testClass));

    TestNG tng = new TestNG();
    tng.setXmlSuites(Arrays.asList(suite));
    try
    {
      tng.run();
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }

}
