Libraries:

Java 17 + Maven
Selenium 3.141.59
TestNG 6.14.3

Structure:

Bootstrapping sequence:

/testautomation/tools/load/shell/jmeterRun.sh - is used to run load testing (main shell script responsible for launching. Define execution time, clean previous artefacts, starts load process(Ex: addOrder*min.jmx)) ("*"= number of minutes to run)
/testautomation/tools/load/jmeter/addOrder*min.jmx - Responsible for launch 10 separated threads emulating 1 real user each (each thread run addOrderLoad*.sh script)
/testautomation/tools/load/shell/addOrder/addOrderLoad*.sh - used for launch TC_AddOrder.java as TestNG test by using RunnerForLoadTesting class. ("*"= 1 t0 10)

Classes in use:

Test - describes main test steps
/testautomation/tools/load/tests/TC_AddOrder.java

Helpers - describes logic of interaction with pages
/testautomation/helpers/umh/LoginHelper.java
/testautomation/helpers/connected/ConnectedHelper.java

TDO(Test Data Objects) - describes objects
/testautomation/tdo/ui/umh/LoginTDO.java
/testautomation/tdo/ui/connected/orders/ConnectedOrderTDO.java

Pages - describes page elements
/testautomation/pages/umh/NavigationBarAndFooterTemplatePage.java
/testautomation/pages/umh/TableActionsPanel.java
/testautomation/pages/umh/LoginPage.java
/testautomation/pages/umh/LogoutPage.java
/testautomation/pages/umh/touchpoints/MessagesPage.java
/testautomation/pages/umh/connected/AddOrderPage.java
/testautomation/pages/umh/connected/ConnectedPage.java
/testautomation/pages/umh/connected/ViewOrderPage.java

