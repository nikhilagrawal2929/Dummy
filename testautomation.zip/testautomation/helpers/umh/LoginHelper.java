package com.company.automation.testautomation.helpers.umh;

import com.company.automation.automationframework.testlog.TestLog;
import com.company.automation.testautomation.enums.umh.TouchpointContentViewPanelValueEnum;
import com.company.automation.testautomation.helpers.general.selenium.ActionsHelper;
import com.company.automation.testautomation.helpers.general.selenium.WebElementHelper;
import com.company.automation.testautomation.pages.umh.LoginPage;
import com.company.automation.testautomation.pages.umh.touchpoints.MessagesPage;
import com.company.automation.testautomation.tdo.ui.umh.LoginTDO;
import com.company.automation.testautomation.templates.Verify;
import org.openqa.selenium.WebDriver;

import java.util.HashMap;

public class LoginHelper
{
  public static final String ENVIRONMENT     = "environment";
  public static final String USERNAME        = "username";
  public static final String PASSWORD        = "password";
  public static final String DOMAIN          = "domain";
  public static final String INSTANCE        = "instance";
  public static final String EXPECTED_RESULT = "expectedResult";
  private static final String LOGIN_SUCCESSFUL = "//*[@class='context-bar btn-toolbar bg-white box-shadow-4']";

  public static LoginTDO setLoginInfo(HashMap<String, String> csv)
  {
    TestLog.step("Try to set required parameters for login");
    LoginTDO loginTDO = new LoginTDO();

    loginTDO.setEnvironment(csv.get(ENVIRONMENT));
    loginTDO.setUser(csv.get(USERNAME));
    loginTDO.setPassword(csv.get(PASSWORD));
    loginTDO.setDomain(csv.get(DOMAIN));
    loginTDO.setInstance(csv.get(INSTANCE));
    loginTDO.setExpectedResult(Boolean.parseBoolean(csv.get(EXPECTED_RESULT)));

    return loginTDO;
  }

  public static MessagesPage login(WebDriver driver, LoginTDO loginTDO)
  {
    TestLog.step("Start to login to UMH");
    LoginPage loginPage = new LoginPage(driver);
    loginPage.clickToggleInstanceBtn(driver);
    loginPage.enterCompanyName(driver, loginTDO.getDomain());
    loginPage.enterInstanceInfo(driver, loginTDO.getInstance());
    loginPage.enterUsername(driver, loginTDO.getUser());
    loginPage.enterPassword(driver, loginTDO.getPassword());
    MessagesPage messagesPage = loginPage.clickLoginBtn(driver);

    if (WebElementHelper.isElementDisplayed(driver, LOGIN_SUCCESSFUL, 4))
    {
      TestLog.step("Login procedure successfully completed with next parameters: "
          + "domain: [" + loginTDO.getDomain() + "], "
          + "instance: [" + loginTDO.getInstance() + "], "
          + "user: [" + loginTDO.getUser() + "], "
          + "password: [" + loginTDO.getPassword() + "]");

      messagesPage.switchToTouchpointContentByPageName(TouchpointContentViewPanelValueEnum.MESSAGES);
      ActionsHelper.sleep(1000);
      messagesPage.openMasterMpBranch();
    }

    return new MessagesPage(driver);
  }

  public static MessagesPage loginViaSSO(WebDriver driver, LoginTDO loginTDO)
  {
    LoginPage loginPage = new LoginPage(driver);
    loginPage.enterCompanyName(driver, loginTDO.getDomain());
    loginPage.clickLoginBtn(driver);
    TestLog.step("Login via SSO with follow parameters: "
        + "domain: [" + loginTDO.getDomain() + "] ");

    return new MessagesPage(driver);
  }

  public static MessagesPage loginWithoutInstance(WebDriver driver, LoginTDO loginTDO)
  {
    LoginPage loginPage = new LoginPage(driver);
    loginPage.clickToggleInstanceBtn(driver);
    loginPage.enterCompanyName(driver, loginTDO.getDomain());
    loginPage.enterUsername(driver, loginTDO.getUser());
    loginPage.enterPassword(driver, loginTDO.getPassword());
    loginPage.clickLoginBtn(driver);
    TestLog.step("Login with follow parameters: "
        + "domain: [" + loginTDO.getDomain() + "], "
        + "user: [" + loginTDO.getUser() + "], "
        + "password: [" + loginTDO.getPassword() + "]");

    return new MessagesPage(driver);
  }

  public static void verifyLogin(MessagesPage messagesPage, LoginTDO loginTDO, Verify verify)
  {
    String expectedBranchName = loginTDO.getDomain();
    String branchName = messagesPage.getBranchName().toLowerCase();
    verify.verifyTrue(expectedBranchName.contains(branchName), "Login failed");
  }
}
