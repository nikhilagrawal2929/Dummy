package com.company.automation.testautomation.helpers.connected;

import java.util.HashMap;
import java.util.List;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import com.company.automation.testautomation.enums.connected.FieldTypeEnum;
import com.company.automation.testautomation.templates.Verify;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.RegexFileFilter;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.xml.sax.SAXException;

import com.company.automation.automationframework.exceptions.general.QualityException;
import com.company.automation.automationframework.profile.AutomationProperties;
import com.company.automation.automationframework.screenshots.ScreenshotSFtpClient;
import com.company.automation.automationframework.testlog.TestLog;
import com.company.automation.testautomation.constants.SystemConstants;
import com.company.automation.testautomation.enums.connected.ConnectedTableEnum;
import com.company.automation.testautomation.enums.umh.SortingEnum;
import com.company.automation.testautomation.helpers.docBridgeDeltaService.DocBridgeDeltaWebServiceHelperWithOkHttp;
import com.company.automation.testautomation.helpers.general.FileHelper;
import com.company.automation.testautomation.helpers.general.OperationalSystemHelper;
import com.company.automation.testautomation.helpers.general.protocols.HtmlHelper;
import com.company.automation.testautomation.helpers.general.protocols.JsonHelper;
import com.company.automation.testautomation.helpers.general.protocols.XmlHelper;
import com.company.automation.testautomation.helpers.general.selenium.ActionsHelper;
import com.company.automation.testautomation.helpers.general.selenium.WebElementHelper;
import com.company.automation.testautomation.helpers.sftp.SftpHelper;
import com.company.automation.testautomation.helpers.umh.NavigationHelper;
import com.company.automation.testautomation.pages.umh.connected.AddOrderPage;
import com.company.automation.testautomation.pages.umh.connected.ConnectedPage;
import com.company.automation.testautomation.pages.umh.connected.ViewOrderPage;
import com.company.automation.testautomation.pages.umh.switch2instance.Switch2InstancePage;
import com.company.automation.testautomation.tdo.output_comparison.pdf_comparison.PDFFileComparisonRequestTDO;
import com.company.automation.testautomation.tdo.ui.connected.orders.ConnectedOrderTDO;
import com.company.automation.testautomation.templates.LineSegment;

public class ConnectedHelper
{
  public static final String ORDER_ID_INPUT_XPATH                     = "//input[@id='%s']";
  public static final String ORDER_ID_LABEL                           = "Order ID";
  public static final String INDICATOR_LABEL                          = "indicator";
  public static final int    FIRST_ROW                                = 1;
  public static final String PAGE_LOAD_COMPLETE_XPATH                 = "//*[@id='page-load-complete']";
  public static final String GET_CURRENT_DROPDOWN_VALUE               = "//*[@class='mceContentMenuValue']";
  public static final String GUID_REGEXP                              = "[^\\s]*-guid=\"[0-9A-F]+\"";
  public static final String INNER_HTML_ATTRIBUTE                     = "innerHTML";
  public static final String DOCUMENT_AREA_XPATH                      = "//*[@id='document-area']";
  public static final String USER_INFO_TAB_XPATH                      = "//*[@id='userInfo']";
  public static final String INSTANCE_XPATH                           = "//*[@aria-controls='instances']";
  public static final String WORKING_INSTANCE_PATTERN                 = "//*[contains ( text(), '%s')]";
  public static final String INSTANCE_TAB_LOADED                      = "//*[@class='collapse show']";
  public static final String EMPTY_LIST_MESSAGE                       = "No matching entries found";
  public static final int    TWO_ITEMS                                = 2;
  public static final String REFERENCE                                = "reference";
  public static final String CANDIDATE                                = "candidate";
  public static final int    HOW_LONG_TO_WAIT_IN_SECONDS_PDF          = 124;
  public static final int    HOW_LONG_TO_WAIT_DOWNLOAD_IN_SECONDS_PDF = 30;
  public static final String PDF_PREFIX                               = ".pdf";
  public static final String REMOTE_DRIVER                            = "RemoteWebDriver";

  public static boolean chooseItemFromDropDownList(WebDriver driver, String dropDownName, String dropDownValue)
  {
    boolean hasItem = false;
    AddOrderPage.openDropDownListByName(driver, dropDownName);
    List<String> menuOptions = AddOrderPage.getItemsFromDropDownList(driver);
    for (String s : menuOptions)
    {
      if (s.compareTo(dropDownValue) == 0)
      {
        hasItem = true;
        AddOrderPage.selectItemFromDropDownList(driver, dropDownValue, dropDownName);
        break;
      }
    }
    return hasItem;
  }

  public static boolean fillOrderValues(WebDriver driver, AddOrderPage addOrderPage, ConnectedOrderTDO connectedOrderTDO)
  {
    List<String> orderFields = connectedOrderTDO.getOrderInterviewFieldsNames();
    List<String> orderValues = connectedOrderTDO.getOrderInterviewValues();
    if (StringUtils.isNotBlank(connectedOrderTDO.getOrderId()))
      addOrderPage.enterTextFieldByTestId(connectedOrderTDO.getOrderTestId(), connectedOrderTDO.getOrderId());

    if (orderFields.size() == orderValues.size())
    {
      for (int i = 0; i < orderFields.size(); i++)
      {
        if (orderFields.get(i).isEmpty() && orderValues.get(i).isEmpty())
        {
          continue;
        }
        if (ConnectedHelper.chooseItemFromDropDownList(driver, orderFields.get(i), orderValues.get(i)))
        {
          // continue
        } else
        {
          return false;
        }
      }
    }

    return true;
  }

  public static boolean fillInterviewValues(WebDriver driver, AddOrderPage addOrderPage, ConnectedOrderTDO connectedOrderTDO)
  {
    List<String> orderTypes = connectedOrderTDO.getOrderInterviewFieldsTypes();
    List<String> orderFields = connectedOrderTDO.getOrderInterviewFieldsNames();
    TestLog.debug("orderFields: " + orderFields);
    List<String> orderValues = connectedOrderTDO.getOrderInterviewValues();
    if (StringUtils.isNotBlank(connectedOrderTDO.getOrderId()))
      addOrderPage.enterTextFieldByTestId(connectedOrderTDO.getOrderTestId(), connectedOrderTDO.getOrderId());

    if (orderTypes.size() == orderFields.size() && orderFields.size() == orderValues.size())
    {
      for (int i = 0; i < orderFields.size(); i++)
      {
        if (StringUtils.isBlank(orderTypes.get(i)) || StringUtils.isBlank(orderFields.get(i)) || StringUtils.isBlank(orderValues.get(i)))
        {
          continue;
        }
        String currentFieldType = orderTypes.get(i);

        if (FieldTypeEnum.DROP_DOWN.getFieldType().equals(currentFieldType))
        {
          if (ConnectedHelper.chooseItemFromDropDownList(driver, orderFields.get(i), orderValues.get(i)))
          {
            // continue
          } else
          {
            return false;
          }
        } else if (FieldTypeEnum.TEXT_FIELD.getFieldType().equals(currentFieldType))
        {
          addOrderPage.enterTextField(orderFields.get(i), orderValues.get(i), orderFields.get(i));
        } else if (FieldTypeEnum.MULTI_SELECT.getFieldType().equals(currentFieldType))
        {
          addOrderPage.chooseValueFromMultiSelect(orderFields.get(i), orderValues.get(i));
        } else if (FieldTypeEnum.DATE_PICKER.getFieldType().equals(currentFieldType))
        {
          addOrderPage.chooseDatePicker(orderFields.get(i), orderValues.get(i));
        }
      }
    }

    return true;
  }

  public static boolean deleteOrderByIndicator(WebDriver driver, ConnectedPage connectedPage, ConnectedOrderTDO connectedOrderTDO)
  {

    // get first line to track the search changes into the table
    LineSegment firstLine = ConnectedTableHelper.getLine(driver, FIRST_ROW);

    // search by indicator
    connectedPage.enterTextToSearchField(driver, connectedOrderTDO.getIndicator());

    // wait for the table to be filtered
    WebElementHelper.waitUntilElemDisappear(driver, TWO_ITEMS, firstLine.getElement());

    // check if the first and single row has the indicator value
    String firstRowIndicator = connectedPage.getTextFromCellByRow(driver, ConnectedTableEnum.INDICATOR, FIRST_ROW);

    // delete the order
    if (connectedOrderTDO.getIndicator().equals(firstRowIndicator))
    {
      int selectCheckboxId = ConnectedTableEnum.SELECT_CHECKBOX.getColumnNumber();
      ConnectedTableHelper.clickTableCheckbox(driver, selectCheckboxId, FIRST_ROW);
      connectedPage.clickMoreBtn(driver);
      connectedPage.clickDeleteBtn();
      connectedPage.clickContinueBtn();

      if (EMPTY_LIST_MESSAGE.compareTo(connectedPage.getEmptyTableLabel()) == 0)
      {
        return true;
      }

    }
    return false;

  }

  public static boolean deleteOrderBySortCreatedColumn(
      WebDriver driver,
      ConnectedPage connectedPage,
      ConnectedOrderTDO connectedOrderTDO
  ) throws QualityException
  {
    ConnectedTableHelper.sortColumn(driver, ConnectedTableEnum.CREATED, SortingEnum.DESCENDING);
    String actualOrderId = connectedPage.getTextFromCellByRow(driver, ConnectedTableEnum.INDICATOR, FIRST_ROW);
    if (actualOrderId.compareTo(connectedOrderTDO.getIndicator()) == 0)
    {
      String dateOfCreationBeforeClickDelete = connectedPage.getTextFromCellByRow(driver, ConnectedTableEnum.CREATED, FIRST_ROW);
      int selectCheckboxId = ConnectedTableEnum.SELECT_CHECKBOX.getColumnNumber();
      ConnectedTableHelper.clickTableCheckbox(driver, selectCheckboxId, FIRST_ROW);
      connectedPage.clickMoreBtn(driver);
      connectedPage.clickDeleteBtn();
      connectedPage.clickContinueBtn();
      String dateOfCreationAfterClickDelete = connectedPage.getTextFromCellByRow(driver, ConnectedTableEnum.CREATED, FIRST_ROW);
      if (dateOfCreationBeforeClickDelete.compareTo(dateOfCreationAfterClickDelete) != 0)
      {
        return true;
      }
    }
    return false;
  }

  public static HashMap<String, String> getSelectedOrderData(WebDriver driver, AddOrderPage addOrderPage, ConnectedOrderTDO connectedOrderTDO)
  {
    List<String> orderFields = connectedOrderTDO.getOrderInterviewFieldsNames();
    HashMap<String, String> actualData = new HashMap<String, String>();

    actualData.put(connectedOrderTDO.getOrderTestId(), addOrderPage.getTextFromTextFieldByTestId(connectedOrderTDO.getOrderTestId()));
    actualData.put(INDICATOR_LABEL, addOrderPage.getTextFromTextField(INDICATOR_LABEL));

    for (int i = 0; i < orderFields.size(); i++)
    {
      if (orderFields.get(i).isEmpty())
      {
        continue;
      }

      String value = addOrderPage.getSelectedValueFromDropdown(driver, orderFields.get(i));
      actualData.put(orderFields.get(i), value);
    }
    return actualData;

  }

  public static boolean checkSelectedOrderData(HashMap<String, String> expectedData, HashMap<String, String> actualData)
  {
    if (expectedData.size() != actualData.size())
    {
      return false;
    }
    boolean res = expectedData.entrySet().stream().allMatch(e -> e.getValue().equals(actualData.get(e.getKey())));
    return res;
  }

  public static void clickButton(WebDriver driver, String title, String xpath)
  {
    waitUntilPageLoadComplete(driver);
    WebElementHelper.clickButton(driver, title, xpath);
  }

  public static void waitUntilPageLoadComplete(WebDriver driver)
  {
    try
    {
      WebElementHelper.waitUntilElementWillBePresentForConnected(driver, PAGE_LOAD_COMPLETE_XPATH);
    } catch (Throwable t)
    {
      TestLog.step("Page hasn't loaded for [" + ConnectedHelper.HOW_LONG_TO_WAIT_IN_SECONDS_PDF + "] seconds.");
      throw t;
    }
  }

  public static boolean compareAllDropdownsValueInEditDocumentArea(WebDriver driver, String value)
  {
    ConnectedHelper.waitUntilPageLoadComplete(driver);
    List<WebElement> els = WebElementHelper.getElements(driver, GET_CURRENT_DROPDOWN_VALUE);

    for (WebElement e : els)
    {
      TestLog.step("Selected value [" + e.getText() + "] in dropdown list");
      if (e.getText().compareTo(value) == 0)
        return true;
    }
    return false;

  }

  public static boolean compareFirstDropdownValueInEditDocumentArea(WebDriver driver, String value)
  {
    ConnectedHelper.waitUntilPageLoadComplete(driver);
    List<WebElement> els = WebElementHelper.getElements(driver, GET_CURRENT_DROPDOWN_VALUE);
    WebElement firstDropdown = els.get(0);
    TestLog.step("Selected value [" + firstDropdown.getText() + "] in dropdown list");
    String firstDropDownValue = firstDropdown.getText().trim();
    if (firstDropDownValue.compareTo(value) == 0)
      return true;
    return false;

  }

  public static ViewOrderPage addOrder(WebDriver driver, ConnectedPage connectedPage, ConnectedOrderTDO connectedOrderTDO)
  {
    AddOrderPage addOrderPage = connectedPage.clickAddOrderBtn();
    TestLog.step("Start to enter order fields.");
    addOrderPage.enterTextField(INDICATOR_LABEL, connectedOrderTDO.getIndicator(), INDICATOR_LABEL);
    ConnectedHelper.fillOrderValues(driver, addOrderPage, connectedOrderTDO);
    ViewOrderPage viewOrderPage = addOrderPage.clickContinueButton();
    ConnectedHelper.waitUntilPageLoadComplete(driver);
    return viewOrderPage;
  }

  public static ViewOrderPage fillConnectedInterview(
      WebDriver driver,
      ConnectedPage connectedPage,
      ConnectedOrderTDO connectedOrderTDO
  ) throws QualityException
  {
    AddOrderPage addOrderPage = connectedPage.clickAddOrderBtn();
    TestLog.step("Start to enter order fields.");
    String xpath = String.format(AddOrderPage.LABEL_PATTERN, INDICATOR_LABEL);
    WebElementHelper.waitUntilElementWillBePresentForConnected(driver, xpath);
    addOrderPage.enterTextField(INDICATOR_LABEL, connectedOrderTDO.getIndicator(), INDICATOR_LABEL);
    ConnectedHelper.fillInterviewValues(driver, addOrderPage, connectedOrderTDO);
    ViewOrderPage viewOrderPage = addOrderPage.clickContinueButton();
    ConnectedHelper.waitUntilPageLoadComplete(driver);
    return viewOrderPage;
  }

  public static boolean compareGoldenHtmlAndJsonVersion(WebDriver driver, ConnectedOrderTDO connectedOrderTDO) throws Exception
  {
    String browser = GoldenVersionHelper.getCurrentBrowser();
    String goldenVersionPath = getGoldenVersionFolder(connectedOrderTDO, browser);

    String currentJsonLayout = getJsonLayoutFromOrder(driver);
    String goldenJsonLayout = FileHelper.getFileAsStringInCharSet(goldenVersionPath, GoldenVersionHelper.JSON_LAYOUT_NAME, null);

    boolean jsonChecked = JsonHelper.compareJson(currentJsonLayout, goldenJsonLayout);

    if (!jsonChecked)
    {
      sendAutomationDataToSFTP(currentJsonLayout, GoldenVersionHelper.JSON_LAYOUT_NAME, "Current JSON data file link: ");
      sendAutomationDataToSFTP(goldenJsonLayout, GoldenVersionHelper.GOLDEN_JSON_LAYOUT_NAME, "Golden JSON data file link: ");
    }

    String currentHtmlDoc = getHtmlDocFromOrder(driver);
    String goldenHtmlDoc = FileHelper.getFileAsStringInCharSet(goldenVersionPath, GoldenVersionHelper.HTML_DOC_NAME, null);

    boolean htmlChecked = HtmlHelper.compareHtml(currentHtmlDoc, goldenHtmlDoc);
    TestLog.step("Comparison status for HTML: expected result: [true], actual result: [" + htmlChecked + "].");

    if (!htmlChecked)
    {

      sendAutomationDataToSFTP(currentHtmlDoc, GoldenVersionHelper.HTML_DOC_NAME, "Current HTML data file link: ");
      sendAutomationDataToSFTP(goldenHtmlDoc, GoldenVersionHelper.GOLDEN_HTML_DOC_NAME, "Golden HTML data file link: ");
    }

    return htmlChecked && jsonChecked;
  }

  public static void sendAutomationDataToSFTP(String data, String fileName, String title) throws QualityException, IOException
  {
    ScreenshotSFtpClient ftpclient = new ScreenshotSFtpClient();
    String path = GoldenVersionHelper.getTempFolder();
    File file = new File(path + fileName);
    FileUtils.writeStringToFile(file, data, StandardCharsets.UTF_8, false);
    String fileUrl = null;
    String platform = OperationalSystemHelper.getOS();
    try
    {
      if (platform.equals(SystemConstants.LINUX))
      {
        ftpclient.connectFromJenkins();
      } else
      {
        ftpclient.connect();
      }
      fileUrl = ftpclient.sendAutomationDataFile(file);
    } catch (Exception e)
    {
      e.printStackTrace();
      System.out.println("Error occurred while file transfer to server. " + e.getMessage());
    } finally
    {
      ftpclient.disconnect();
      file.delete();
      TestLog.step(title + fileUrl);
    }

  }

  public static String getJsonLayoutFromOrder(WebDriver driver)
  {
    WebElementHelper.callJSFunction(driver, "window.automationHook()");

    WebElement layoutDataElement = WebElementHelper.getDomElement(driver, GoldenVersionHelper.AUTOMATION_DATA_XPATH);
    String layoutData = WebElementHelper.getElementAttributeByXpath(driver, layoutDataElement, "value");

    return layoutData;
  }

  public static String getHtmlDocFromOrder(WebDriver driver) throws ParserConfigurationException, IOException, TransformerException, SAXException
  {
    String documentAreaHtml = WebElementHelper.getElementAttributeByXpath(driver, INNER_HTML_ATTRIBUTE, DOCUMENT_AREA_XPATH);
    documentAreaHtml = documentAreaHtml.replaceAll("\\u200B", "&#x200B;");
    documentAreaHtml = documentAreaHtml.replaceAll("\\u200C", "&#x200C;");
    documentAreaHtml = documentAreaHtml.replaceAll("\\u200D", "&#x200D;");
    documentAreaHtml = documentAreaHtml.replaceAll("\\uFEFF", "&#xFEFF;");

    String res = XmlHelper.normalize(HtmlHelper.ROOT_XML_ELEMENT_START + HtmlHelper.normalize(documentAreaHtml) + HtmlHelper.ROOT_XML_ELEMENT_END);

    return res;
  }

  public static String getGoldenVersionFolder(ConnectedOrderTDO connectedOrderTDO, String browser) throws QualityException
  {
    String path = AutomationProperties.getProperty(SystemConstants.MASTER_DATA_PATH)
        + connectedOrderTDO.getTestEnv() + "/"
        + connectedOrderTDO.getClient() + "/"
        + connectedOrderTDO.getInstance() + "/" + browser + "/" + connectedOrderTDO.getNickname();
    File saveDirectory = new File(path);
    if (!saveDirectory.exists())
    {
      return null;
    }

    return path;
  }

  public static String getInstance(WebDriver driver)
  {
    TestLog.step("Try to get selected instance");
    WebElement userInfo = WebElementHelper.getElement(driver, USER_INFO_TAB_XPATH);
    userInfo.click();
    WebElement instance = WebElementHelper.getElement(driver, INSTANCE_XPATH);
    String text = instance.getText().toLowerCase();
    return text;
  }

  public static boolean IsWorkingInstanceActive(WebDriver driver, String name)
  {
    String text = getInstance(driver);
    boolean res = text.contains(name);
    return res;
  }

  public static void changeInstance(WebDriver driver, ConnectedOrderTDO connectedOrderTDO)
  {
    boolean res = IsWorkingInstanceActive(driver, connectedOrderTDO.getInstance());
    WebElement instance = WebElementHelper.getElement(driver, INSTANCE_XPATH);
    instance.click();
    if (!res)
    {
      WebElementHelper.waitUntilNumberOfElementsBiggerThanExpResultByXpath(driver, INSTANCE_TAB_LOADED, 0);
      WebElementHelper.findAndClickElementByText(driver, " " + connectedOrderTDO.getInstance() + " ");
      Switch2InstancePage switch2InstancePage = new Switch2InstancePage(driver);
      switch2InstancePage.enterPassword(driver, connectedOrderTDO.getPassword());
      switch2InstancePage.clickConfirmButton();
      TestLog.step("Instance has changed to [" + connectedOrderTDO.getInstance() + "]");
    } else
    {
      String workingInstance = String.format(WORKING_INSTANCE_PATTERN, connectedOrderTDO.getInstance());
      WebElement el = WebElementHelper.getElement(driver, workingInstance);
      ActionsHelper.moveToElementAndClick(driver, el);
      TestLog.step("The current instance is [" + connectedOrderTDO.getInstance() + "]");
    }
  }

  public static ViewOrderPage loginAndAddOrderBeforeSubmit(WebDriver driver, ConnectedOrderTDO connectedOrderTDO, HashMap<String, String> csv)
  {
    TestLog.step("Start to login to UI application and open connected page via google waffle");
    ConnectedPage connectedPage = NavigationHelper.loginAndOpenConnectedAppViaGoogleWaffle(driver, csv);
    TestLog.step("Start to create new order [" + connectedOrderTDO.getNickname() + "]");
    ViewOrderPage viewOrderPage = ConnectedHelper.addOrder(driver, connectedPage, connectedOrderTDO);
    return viewOrderPage;
  }

  public static ViewOrderPage loginAndFillInterviewForNewOrder(
      WebDriver driver,
      ConnectedOrderTDO connectedOrderTDO,
      HashMap<String, String> csv
  ) throws QualityException
  {
    TestLog.step("Start to login to UI application and open connected page via google waffle");
    ConnectedPage connectedPage = NavigationHelper.loginAndOpenConnectedAppViaGoogleWaffle(driver, csv);
    TestLog.step("Start to create new order [" + connectedOrderTDO.getNickname() + "]");
    ViewOrderPage viewOrderPage = ConnectedHelper.fillConnectedInterview(driver, connectedPage, connectedOrderTDO);
    return viewOrderPage;
  }

  public static boolean cleanOrderDataViaBackToInterviewBtn(ViewOrderPage viewOrderPage, ConnectedOrderTDO connectedOrderTDO) throws QualityException
  {
    TestLog.step("Post step: Clean order data and remove order from table");
    AddOrderPage addOrderPage = viewOrderPage.clickBackToInterviewBtn();
    ConnectedPage connectedPage = addOrderPage.clickCancelButton();

    TestLog.step("Start to delete order [" + connectedOrderTDO.getNickname() + "] by sorting the list descending and pick the last created order.");
    boolean result = ConnectedHelper.deleteOrderByIndicator(connectedPage.getDriver(), connectedPage, connectedOrderTDO);
    return result;
  }

  public static boolean clearOrderDataByCancelButton(ViewOrderPage viewOrderPage, ConnectedOrderTDO connectedOrderTDO)
  {
    TestLog.step("Post step: Clear order data and remove order from table");
    ConnectedPage connectedPage = viewOrderPage.clickCancelBtn();
    TestLog.step("Start to delete order [" + connectedOrderTDO.getNickname() + "] by sorting the list descending and pick the last created order.");
    boolean result = ConnectedHelper.deleteOrderByIndicator(connectedPage.getDriver(), connectedPage, connectedOrderTDO);
    return result;
  }

  public static File prepareAndDownloadPDF(ViewOrderPage viewOrderPage)
  {
    String searchDir = "";
    String browser = GoldenVersionHelper.getCurrentBrowser();
    String platform = OperationalSystemHelper.getOS();
    viewOrderPage.clickProofButton();
    viewOrderPage.clickPdfIndicator();
    viewOrderPage.clickDownloadPDF();
    ActionsHelper.sleep(4000); // wait for download

    switch (platform)
    {
    case SystemConstants.WINDOWS:
      searchDir = System.getProperty(SystemConstants.USER_DIR) + SystemConstants.MASTER_DOWNLOAD_PATH_FROM_SRC;
      break;
    case SystemConstants.WINDOWS10:
      searchDir = System.getProperty(SystemConstants.USER_DIR) + SystemConstants.MASTER_DOWNLOAD_PATH_FROM_SRC;
      break;
    case SystemConstants.LINUX:

      if (browser.compareTo("firefox") == 0)
      {
        searchDir = SystemConstants.FIREFOX_DOWNLOAD_DEFAULT_PATH_LINUX;
      } else
        searchDir = System.getProperty(SystemConstants.USER_DIR) + SystemConstants.MASTER_DOWNLOAD_PATH_FROM_SRC_LINUX;
      break;
    case SystemConstants.MAC:
      searchDir = System.getProperty(SystemConstants.USER_DIR) + SystemConstants.MASTER_DOWNLOAD_PATH_FROM_SRC_LINUX;
      break;
    }
    System.out.println("Downloaded file is in: " + searchDir);
    FileHelper.waitForFileToAppearInFolderUntilTimeout(searchDir, PDF_PREFIX, HOW_LONG_TO_WAIT_DOWNLOAD_IN_SECONDS_PDF);
    FileFilter filter = new RegexFileFilter(GoldenVersionHelper.PDF_FILE_NAME_REGEX);
    File generatedPdf = FileHelper.findFile(searchDir, filter); // particular name of file
    
    return generatedPdf;
  }

  public static boolean prepare2PdfFilesAndCompareViaDocBridgeService(File currentFile, File goldenFile, HashMap<String, String> csv)
  {
    FileHelper.setWritableAndExecutableFilePermission(goldenFile, true);
    FileHelper.setWritableAndExecutableFilePermission(currentFile, true);

    csv.put(REFERENCE, goldenFile.getName());
    csv.put(CANDIDATE, currentFile.getName());
    PDFFileComparisonRequestTDO pDFFileComparisonRequestTDO = DocBridgeDeltaWebServiceHelperWithOkHttp.setUpRequestTDO(csv);

    TestLog.step("Try to send PDF files to compare service");
    boolean compareStatus = DocBridgeDeltaWebServiceHelperWithOkHttp.comparePdfFiles(goldenFile, currentFile, pDFFileComparisonRequestTDO, true, null);

    return compareStatus;
  }

  public static void generateGoldenHtmlAndJson(WebDriver driver, ConnectedOrderTDO connectedOrderTDO) throws Exception
  {
    TestLog.step("Start to generate HTML/JSON golden version");
    GoldenVersionHelper.generateHtmlAndJsonAutomationData(driver, connectedOrderTDO);
  }

  public static File getGoldenPdf(ConnectedOrderTDO connectedOrderTDO)
  {
    File goldenPdf;
    String goldenPath = GoldenVersionHelper.getGoldenPath(connectedOrderTDO);
    FileFilter filter = new RegexFileFilter(GoldenVersionHelper.PDF_FILE_NAME_REGEX);
    goldenPdf = FileHelper.findFile(goldenPath, filter);
    return goldenPdf;
  }

  public static File generateGoldenPdf(ViewOrderPage viewOrderPage, ConnectedOrderTDO connectedOrderTDO)
  {
    TestLog.step("Start to generate PDF golden version");
    File goldenPdf = GoldenVersionHelper.generatePdfAutomationData(viewOrderPage, connectedOrderTDO);
    return goldenPdf;
  }

  public static void compareGoldenPdfVersion(ViewOrderPage viewOrderPage, ConnectedOrderTDO connectedOrderTDO, HashMap<String, String> csv, Verify verify)
  {
    // get golden version or generate if needed
    File goldenPdf = ConnectedHelper.getGoldenPdf(connectedOrderTDO);
    File currentFile = null;
    boolean compareStatus;
    // Start to prepare and download current PDF file.
    TestLog.step("Start to prepare and download current PDF file");
    currentFile = ConnectedHelper.prepareAndDownloadPDF(viewOrderPage);
    TestLog.step("Current PDF with name:[" + currentFile.getName() + "]" + " was downloaded to the folder:[" + currentFile.getParent() + "]");
    currentFile.setExecutable(true);
    TestLog.step("Try to send current pdf [" + currentFile.getName() + "] to SFTP");
    SftpHelper.uploadFileToSftp(currentFile);

    // Compare 2 PDF via doc bridge service.
    TestLog.step("Start to prepare and compare 2 PDF files via doc bridge service");
    compareStatus = ConnectedHelper.prepare2PdfFilesAndCompareViaDocBridgeService(currentFile, goldenPdf, csv);
    TestLog.step("PDF comparison status: differences found: [" + compareStatus + "]");
    verify.verifyFalse(compareStatus, "Check that PDF files has no differences");
    if (currentFile != null)
    {
      FileHelper.deleteFile(currentFile);
    }
  }

  public static void useOurCodeAsToolOrTest(
      WebDriver driver,
      boolean generateGoldenVersion,
      ConnectedOrderTDO connectedOrderTDO,
      HashMap<String, String> csv,
      Verify verify,
      ViewOrderPage viewOrderPage
  )
  {
    try
    {
      if (generateGoldenVersion)
      {
        ConnectedHelper.generateGoldenHtmlAndJson(driver, connectedOrderTDO);
        ConnectedHelper.generateGoldenPdf(viewOrderPage, connectedOrderTDO);
      } else
      {
        boolean res = ConnectedHelper.compareGoldenHtmlAndJsonVersion(driver, connectedOrderTDO);
        verify.verifyTrue(res, "HTML/JSON has differences");
        ConnectedHelper.compareGoldenPdfVersion(viewOrderPage, connectedOrderTDO, csv, verify);

      }
    } catch (Exception e)
    {
      throw new RuntimeException(e);
    }
  }

  public static void clearGeneratedPdfFiles()
  {
    String searchDir;
    String platform = OperationalSystemHelper.getOS();
    switch (platform)
    {
    case SystemConstants.LINUX:
      String browser = GoldenVersionHelper.getCurrentBrowser();
      if (browser.compareTo(SystemConstants.FIREFOX) == 0)
      {
        searchDir = SystemConstants.FIREFOX_DOWNLOAD_DEFAULT_PATH_LINUX;
        FileHelper.findFileInFolderByPatternAndDelete(searchDir, GoldenVersionHelper.PDF_FILE_NAME_REGEX);
      } else
        searchDir = System.getProperty(SystemConstants.USER_DIR) + SystemConstants.MASTER_DOWNLOAD_PATH_FROM_SRC_LINUX;
      FileHelper.findFileInFolderByPatternAndDelete(searchDir, GoldenVersionHelper.PDF_FILE_NAME_REGEX);
      break;
    case SystemConstants.WINDOWS:
      searchDir = System.getProperty(SystemConstants.USER_DIR) + SystemConstants.MASTER_DOWNLOAD_PATH_FROM_SRC;
      FileHelper.findFileInFolderByPatternAndDelete(searchDir, GoldenVersionHelper.PDF_FILE_NAME_REGEX);
      break;
    case SystemConstants.WINDOWS10:
      searchDir = System.getProperty(SystemConstants.USER_DIR) + SystemConstants.MASTER_DOWNLOAD_PATH_FROM_SRC;
      FileHelper.findFileInFolderByPatternAndDelete(searchDir, GoldenVersionHelper.PDF_FILE_NAME_REGEX);
      break;
    case SystemConstants.MAC:
      searchDir = System.getProperty(SystemConstants.USER_DIR) + SystemConstants.MASTER_DOWNLOAD_PATH_FROM_SRC;
      FileHelper.findFileInFolderByPatternAndDelete(searchDir, GoldenVersionHelper.PDF_FILE_NAME_REGEX);
      break;
    }
  }
}
