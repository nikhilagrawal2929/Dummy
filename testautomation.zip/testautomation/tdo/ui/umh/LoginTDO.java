package com.company.automation.testautomation.tdo.ui.umh;

public class LoginTDO
{
  protected String  environment    = "";
  protected String  user           = "";
  protected String  password       = "";
  protected String  domain         = "";
  protected String  instance       = "";
  protected boolean expectedResult = false;

  public LoginTDO()
  {
  }

  public LoginTDO(String user, String password, String domain, String instance, boolean expectedResult)
  {
    this.user = user;
    this.password = password;
    this.domain = domain;
    this.instance = instance;
    this.expectedResult = expectedResult;
  }

  public String getUser()
  {
    return user;
  }

  public void setUser(String user)
  {
    this.user = user;
  }

  public String getPassword()
  {
    return password;
  }

  public void setPassword(String password)
  {
    this.password = password;
  }

  public String getDomain()
  {
    return domain;
  }

  public void setDomain(String domain)
  {
    this.domain = domain;
  }

  public String getInstance()
  {
    return instance;
  }

  public void setInstance(String instance)
  {
    this.instance = instance;
  }

  public boolean getExpectedResult()
  {
    return expectedResult;
  }

  public void setExpectedResult(boolean expectedResult)
  {
    this.expectedResult = expectedResult;
  }

  public String getEnvironment()
  {
    return environment;
  }

  public void setEnvironment(String environment)
  {
    this.environment = environment;
  }
}
