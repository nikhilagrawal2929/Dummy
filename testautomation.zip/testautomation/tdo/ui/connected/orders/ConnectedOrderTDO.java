package com.company.automation.testautomation.tdo.ui.connected.orders;

import com.company.automation.automationframework.helpers.PropertiesReaderHelper;
import com.company.automation.automationframework.profile.AutomationProperties;
import com.company.automation.automationframework.testrail.TestRunnerContext;
import com.company.automation.testautomation.helpers.general.DateHelper;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

public class ConnectedOrderTDO
{

  public static final String NICKNAME                  = "nickname";
  public static final String CLIENT                    = "client";
  public static final String TEST_ENV                  = "test-env";
  public static final String GOLDEN_VERSION            = "generateGoldenVersion";
  public static final String GOLDEN_VERSION_PREFIX     = "GOLD_";
  public static final String ORDER_TEST_ID             = "order-test-id";
  public static final String ORDER_ID                  = "order-id";
  public static final String EXP_RESULT                = "expectedResult";
  public static final String ACTUAL_RESULT             = "actualResult";
  public static final String ORDER_ID_LABEL            = "Order ID";
  public static final String INDICATOR                 = "indicator";
  public static final String INSTANCE                  = "instance";
  public static final String PASSWORD                  = "password";
  public static final String DROPDOWN_NAME_EDIT_AREA   = "dropdownNameEditArea";
  public static final String DROPDOWN_VALUE_EDIT_AREA  = "dropdownValueEditArea";
  public static final String DROPDOWN_NAME_EDIT_AREA2  = "dropdownNameEditArea2";
  public static final String DROPDOWN_VALUE_EDIT_AREA2 = "dropdownValueEditArea2";
  public static final String DROPDOWN_NAME_EDIT_AREA3  = "dropdownNameEditArea3";
  public static final String DROPDOWN_VALUE_EDIT_AREA3 = "dropdownValueEditArea3";

  String            nickname                  = new String();
  String            client                    = new String();
  String            test_env                  = new String();
  String            instance                  = new String();
  String            orderTestId               = new String();
  String            orderId                   = new String();
  String            indicator                 = new String();
  String            password                  = new String();
  String            dropdownNameEditArea      = new String();
  String            dropdownValueEditArea     = new String();
  String            dropdownNameEditArea2     = new String();
  String            dropdownValueEditArea2    = new String();
  String            dropdownNameEditArea3     = new String();
  String            dropdownValueEditArea3    = new String();
  ArrayList<String> orderInterviewFieldsTypes = new ArrayList<String>();
  ArrayList<String> orderInterviewFieldsNames = new ArrayList<String>();
  ArrayList<String> orderInterviewValues      = new ArrayList<String>();
  boolean           generateGoldenVersion;
  boolean           expected_result;
  boolean           actual_result;

  public ConnectedOrderTDO(HashMap<String, String> csv)
  {
    setOrderInterviewFieldsTypes(csv);
    setOrderInterviewFieldsNames(csv);
    setOrderInterviewValues(csv);
    nickname = csv.get(NICKNAME);
    client = csv.get(CLIENT);
    instance = csv.get(INSTANCE);
    test_env = csv.get(TEST_ENV);
    try
    {
      String server = AutomationProperties.getProperty("app.server");
      PropertiesReaderHelper reader = new PropertiesReaderHelper("maven.properties");
      String env = reader.getProperty("env");
      String testEnvProperty = String.format(server, env);

      String testEnv = testEnvProperty.substring(8, testEnvProperty.indexOf('.'));
      test_env = testEnv;
    } catch (Throwable e)
    {
    }
    orderTestId = csv.get(ORDER_TEST_ID);
    orderId = csv.get(ORDER_ID);
    indicator = csv.get(INDICATOR);
    password = csv.get(PASSWORD);
    String marker = TestRunnerContext.getGoldenMarker();
    if (marker.compareTo("undefined") == 0)
    {
      generateGoldenVersion = Boolean.parseBoolean(csv.get(GOLDEN_VERSION));
    } else
    {
      generateGoldenVersion = Boolean.valueOf(TestRunnerContext.getGoldenMarker());
    }

    expected_result = Boolean.parseBoolean(csv.get(EXP_RESULT));
    actual_result = Boolean.parseBoolean(csv.get(ACTUAL_RESULT));
    dropdownNameEditArea = csv.get(DROPDOWN_NAME_EDIT_AREA);
    dropdownValueEditArea = csv.get(DROPDOWN_VALUE_EDIT_AREA);
    dropdownNameEditArea2 = csv.get(DROPDOWN_NAME_EDIT_AREA2);
    dropdownValueEditArea2 = csv.get(DROPDOWN_VALUE_EDIT_AREA2);
    dropdownNameEditArea3 = csv.get(DROPDOWN_NAME_EDIT_AREA3);
    dropdownValueEditArea3 = csv.get(DROPDOWN_VALUE_EDIT_AREA3);
  }

  public String getPassword()
  {
    return password;
  }

  public void setPassword(String password)
  {
    this.password = password;
  }

  public String getInstance()
  {
    return instance;
  }

  public void setInstance(String instance)
  {
    this.instance = instance;
  }

  public String getIndicator()
  {
    if (indicator == null)
    {
      indicator = (generateGoldenVersion ? GOLDEN_VERSION_PREFIX : "") + nickname + "_" + DateHelper.getDateTimeAsString(new Date());
    }
    return indicator;
  }

  public void setIndicator(String indicator)
  {
    this.indicator = indicator;
  }

  public String getNickname()
  {
    return nickname;
  }

  public void setNickname(String nickname)
  {
    this.nickname = nickname;
  }

  public String getClient()
  {
    return client;
  }

  public void setClient(String client)
  {
    this.client = client;
  }

  public String getTestEnv()
  {
    return test_env;
  }

  public void setTestEnv(String test_env)
  {
    this.test_env = test_env;
  }

  public boolean getGenerateGoldenVersion()
  {
    return generateGoldenVersion;
  }

  public void setGenerateGoldenVersion(boolean generateGoldenVersion)
  {
    this.generateGoldenVersion = generateGoldenVersion;
  }

  public String getOrderTestId()
  {
    return orderTestId;
  }

  public void setOrderTestId(String orderTestId)
  {
    this.orderTestId = orderTestId;
  }

  public String getOrderId()
  {
    return orderId;
  }

  public void setOrderId(String order_id)
  {
    this.orderId = orderId;
  }

  public boolean getExpectedResult()
  {
    return expected_result;
  }

  public void setExpectedResult(boolean expected_result)
  {
    this.expected_result = expected_result;
  }

  public boolean getActualResult()
  {
    return actual_result;
  }

  public void setActualResult(boolean actual_result)
  {
    this.actual_result = actual_result;
  }

  public ArrayList<String> getOrderInterviewFieldsTypes()
  {
    return orderInterviewFieldsTypes;
  }

  public void setOrderInterviewFieldsTypes(HashMap<String, String> csv)
  {
    String str = csv.get("ORDER_INTERVIEW_FIELD_TYPES_SEQUENCE");
    if (StringUtils.isNotBlank(str))
      this.orderInterviewFieldsTypes = new ArrayList<String>(Arrays.asList(str.split("#")));
  }

  public List<String> getOrderInterviewFieldsNames()
  {
    return orderInterviewFieldsNames;
  }

  public void setOrderInterviewFieldsNames(HashMap<String, String> csv)
  {
    String str = csv.get("ORDER_INTERVIEW_FIELDS_NAMES_SEQUENCE");
    this.orderInterviewFieldsNames = new ArrayList<String>(Arrays.asList(str.split("#")));
  }

  public List<String> getOrderInterviewValues()
  {
    return orderInterviewValues;
  }

  public void setOrderInterviewValues(HashMap<String, String> csv)
  {
    String str = csv.get("ORDER_INTERVIEW_VALUES_SEQUENCE");
    this.orderInterviewValues = new ArrayList<String>(Arrays.asList(str.split("#")));
  }

  public HashMap<String, String> fullOrderData()
  {
    List<String> orderFields = getOrderInterviewFieldsNames();
    List<String> orderValues = getOrderInterviewValues();

    orderFields.removeIf(String::isEmpty);
    orderValues.removeIf(String::isEmpty);

    HashMap<String, String> selectedData = new HashMap<String, String>();
    selectedData.put(orderTestId, orderId);
    selectedData.put(INDICATOR, getIndicator());

    if (orderFields.size() == orderValues.size())
    {
      for (int i = 0; i < orderFields.size(); i++)
      {
        selectedData.put(orderFields.get(i), orderValues.get(i));
      }
    }
    return selectedData;
  }

  public String getDropdownNameEditArea()
  {
    return dropdownNameEditArea;
  }

  public void setDropdownNameEditArea(String dropdownNameEditArea)
  {
    this.dropdownNameEditArea = dropdownNameEditArea;
  }

  public String getDropdownValueEditArea()
  {
    return dropdownValueEditArea;
  }

  public void setDropdownValueEditArea(String dropdownValueEditArea)
  {
    this.dropdownValueEditArea = dropdownValueEditArea;
  }

  public String getDropdownNameEditArea2()
  {
    return dropdownNameEditArea2;
  }

  public void setDropdownNameEditArea2(String dropdownNameEditArea2)
  {
    this.dropdownNameEditArea2 = dropdownNameEditArea2;
  }

  public String getDropdownValueEditArea2()
  {
    return dropdownValueEditArea2;
  }

  public void setDropdownValueEditArea2(String dropdownValueEditArea2)
  {
    this.dropdownValueEditArea2 = dropdownValueEditArea2;
  }

  public String getDropdownNameEditArea3()
  {
    return dropdownNameEditArea3;
  }

  public void setDropdownNameEditArea3(String dropdownNameEditArea3)
  {
    this.dropdownNameEditArea3 = dropdownNameEditArea3;
  }

  public String getDropdownValueEditArea3()
  {
    return dropdownValueEditArea3;
  }

  public void setDropdownValueEditArea3(String dropdownValueEditArea3)
  {
    this.dropdownValueEditArea3 = dropdownValueEditArea3;
  }
}
